
#define BUILD_FLOW_METER



#ifdef BUILD_PH_METER
#include "phmeter/PhMeterMain.h"
#endif

#ifdef BUILD_FLOW_METER
#include "flowmeter/FlowMeterMain.h"
#endif




void setup() 
{
	#ifdef BUILD_PH_METER
	setupPhMeter();
	#endif

	#ifdef BUILD_FLOW_METER
	setupFlowMeter();
	#endif

}


void loop() 
{
	#ifdef BUILD_PH_METER
	loopPhMeter();
	#endif	

	#ifdef BUILD_FLOW_METER
	loopFlowMeter();
	#endif
}
