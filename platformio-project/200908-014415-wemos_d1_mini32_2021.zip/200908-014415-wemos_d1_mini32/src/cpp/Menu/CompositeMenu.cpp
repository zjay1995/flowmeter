#include "base/Menu/CompositeMenu.h"


CompositeMenu::CompositeMenu(String name, String parentName, std::vector<MenuWithSelection*> menus) : MenuWithSelection(name, parentName, nullptr),
                                                                                        m_menus(menus),
                                                                                        m_currentIndex(0)
{
    
}

Menu* CompositeMenu::getCurrentMenu()
{
    return m_menus[ m_currentIndex ];
}


void CompositeMenu::moveToFirst()
{
    m_currentIndex = 0;
}

void CompositeMenu::moveToPrev()
{
    m_currentIndex = (m_currentIndex - 1 + m_menus.size()) % m_menus.size();
    Serial.println("moveToPrev" + String(m_currentIndex) + " " + String(m_menus.size()) );
    Serial.println("moveToPrev: " + m_menuName );	
    Serial.flush();
}

void CompositeMenu::moveToNext()
{
    m_currentIndex = (m_currentIndex + 1) % m_menus.size();
    Serial.println("moveToNext" + String(m_currentIndex) + " " + String(m_menus.size()) );
    Serial.println("moveToNext: " + m_menuName );	
    Serial.flush();
}

void CompositeMenu::action(EMenuAction eMenuAction)
{
    Serial.println("CompositeMenu::action: " + String(eMenuAction) + " " + String(m_currentIndex) + " name: " + m_menus[m_currentIndex]->getName() + " s: " + String(m_menus[m_currentIndex]->isSelectionModeActive()));	
    Serial.flush();

    if(m_menus[m_currentIndex]->isSelectionModeActive())
    {
        m_menus[m_currentIndex]->action(eMenuAction);
        return;
    }

    switch(eMenuAction)
    {
        case EMenuAction::S_SINGLE_CLICK_LONG:
        case EMenuAction::S_SINGLE_CLICK_SHORT:
            Serial.println("CompositeMenu::action: S_SINGLE_CLICK");	
            Serial.flush();
            m_menus[m_currentIndex]->action(eMenuAction);
            break;
        case EMenuAction::UP_SINGLE_CLICK_SHORT:
            moveToNext();
            break;
        case EMenuAction::DOWN_SINGLE_CLICK_SHORT:
            moveToPrev();
            break;
    }

}

void CompositeMenu::render() 
{
    //Serial.println("RENDER COMP : " + m_menuName );
    //Serial.flush();
    m_menus[ m_currentIndex ]->render();
}

void CompositeMenu::print()
{
    Serial.println("Menu name: " + m_menuName + " Parent name: " + m_parentMenuName );
    for(Menu* m : m_menus)
        Serial.println("Menu name: " + m->getName() + " Parent name: " + m->getParentName() );
    Serial.flush();
}