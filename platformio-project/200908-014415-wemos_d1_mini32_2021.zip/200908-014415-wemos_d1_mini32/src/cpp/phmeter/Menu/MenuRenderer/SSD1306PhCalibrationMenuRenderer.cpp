#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306PhCalibrationMenuRenderer.h"
#include "phmeter/DataSource/PhSensorDataSource.h"


SSD1306PhCalibrationMenuRenderer::SSD1306PhCalibrationMenuRenderer(SSD1306Wire* display, PhSensorDataSource* phSensorDataSource, PhManager* phManager) : SSD1306MenuRenderer(display),
																														  m_phSensorDataSource(phSensorDataSource),
																														  m_phManager(phManager)	
{
	
	
}


void SSD1306PhCalibrationMenuRenderer::render(Menu* menu)
{
	m_display->clear();
	m_display->setColor(WHITE);
	m_display->setTextAlignment(TEXT_ALIGN_CENTER);
	m_display->drawString(64, 0 , "Calibration");

	String mvLine = String(m_phSensorDataSource->getRawMiliVolts()) + " mv";

	m_display->drawString(64, 30 , mvLine);	

	m_display->setFont(ArialMT_Plain_16);
	m_display->drawString(64, 47 , menu->getInfoMessage());
	m_display->display();
}