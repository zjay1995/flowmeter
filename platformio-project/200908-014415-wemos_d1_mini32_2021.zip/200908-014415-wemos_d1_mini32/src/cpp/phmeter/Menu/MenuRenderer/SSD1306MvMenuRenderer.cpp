#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306MvMenuRenderer.h"
#include "phmeter/PhManager.h"
#include <SSD1306.h>


SSD1306MvMenuRenderer::SSD1306MvMenuRenderer(SSD1306Wire* display, PhManager* phManager) : SSD1306MenuRenderer(display),
                                                                                           m_phManager(phManager)
{


}	

void SSD1306MvMenuRenderer::render(Menu* menu)
{
	m_display->clear();
	m_display->setColor(WHITE);
	m_display->setTextAlignment(TEXT_ALIGN_CENTER);

    String textToDisplay = "mV";

	if(m_phManager->getItemOfInterest() == EItemOfInterest::MV)
	{
		textToDisplay = "mV *";
	}

	m_display->drawString(64, 30, textToDisplay);
	m_display->display();        
}