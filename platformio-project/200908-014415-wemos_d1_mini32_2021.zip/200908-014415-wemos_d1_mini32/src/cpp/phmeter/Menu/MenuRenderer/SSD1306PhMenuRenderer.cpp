#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306PhMenuRenderer.h"
#include "phmeter/PhManager.h"
#include <SSD1306.h>


SSD1306PhMenuRenderer::SSD1306PhMenuRenderer(SSD1306Wire* display, PhManager* phManager) : SSD1306MenuRenderer(display),
                                                                                           m_phManager(phManager)
{


}	

void SSD1306PhMenuRenderer::render(Menu* menu)
{
	m_display->clear();
	m_display->setColor(WHITE);
	m_display->setTextAlignment(TEXT_ALIGN_CENTER);

    String textToDisplay = "pH";

	if(m_phManager->getItemOfInterest() == EItemOfInterest::PH)
	{
		textToDisplay = "pH *";
	}

	m_display->drawString(64, 30, textToDisplay);
	m_display->display();        
}