#include "phmeter/PhMeterMain.h"


#include <Adafruit_ADS1015.h>
#include <SSD1306.h>
#include <oled.h>
#include <U8g2lib.h>

#include <WiFi.h>
#include <vector>

#include "base/TimeSync.h"
#include "phmeter/PhMAnager.h"
#include "base/Button.h"
#include "base/Menu/Menu.h"
#include "base/Menu/MenuRenderer/MenuRenderer.h"
#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306PhRunMenuRenderer.h"
#include "base/Menu/MenuRenderer/SSD1306/SSD1306GenericMenuRenderer.h"
#include "base/Menu/MenuRenderer/SSD1306/SSDGenericMenuWithSelectionRenderer.h"
#include "base/Menu/CompositeMenu.h"
#include "base/SleepTimer.h"
#include "base/Globals.h"
#include "base/DataLogger/DataLogger.h"
#include "base/DataSource/AnalogSourceInput.h"

#include "phmeter/WebServer/PhMeterWebServer.h"

#include "phmeter/PhConfigurationManager.h"
#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306PhCalibrationMenuRenderer.h"
#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306PhMenuRenderer.h"
#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306MvMenuRenderer.h"

#include "phmeter/Menu/CalibrationMenuItem.h"
#include "phmeter/Menu/PhMenuItem.h"
#include "phmeter/Menu/MvMenuItem.h"

#include "base/Menu/MenuRenderer/SSD1327/SSDGenericMenuWithSelectionRenderer.h"


using namespace std;


//#define USE_SSD1306_DISPLAY
#define USE_SSD1306_DISPLAY


#define MAX_SCCM 5000

#define wifi_ssid "1134ea"
#define wifi_password "DNm11i223344"


PhConfigurationManager g_configurationManager;

PhManager g_phManager;

PhMeterWebServer* g_pWebServer = new PhMeterWebServer();

CompositeMenu* g_mainMenu = nullptr; 

Adafruit_ADS1115 ads1115;

#ifdef USE_SSD1306_DISPLAY
SSD1306 display(0x3c, 5, 4);
#endif

#ifdef USE_SSD1327_DISPLAY
U8G2_SSD1327_MIDAS_128X128_F_4W_SW_SPI display(U8G2_R0, /* clock=*/ 27, /* data=*/ 26, /* cs=*/ 25, /* dc=*/ 33, /* reset=*/ 32);
#endif

SleepTimer g_sleepTimer;

DataLogger g_dataLogger;

TimeSync g_timeSync;

const char* ssid     = "ESP32-Access-Point";
const char* password = "91239";

volatile bool CALIBRATION_MODE = false;

void setupButtons();

void setupWiFi() {
	Serial.print("Setting AP (Access Point)…");
	// Remove the password parameter, if you want the AP (Access Point) to be open
	WiFi.softAP(ssid, password);

	IPAddress IP = WiFi.softAPIP();
	Serial.print("AP IP address: ");
	Serial.println(IP);

	g_pWebServer->begin(80);
}


void setupButtons()
{
	//pinMode(14, INPUT_PULLUP);
	//pinMode(2, INPUT_PULLUP);
	//pinMode(0, INPUT_PULLUP);
	//pinMode(15, INPUT_PULLUP);
	
	Keyboard* keyboard = new Keyboard();
		
	keyboard->addOnDownPressedFctor([]{
		
		//g_sleepTimer.resetIdleCounter();
		
		if(CALIBRATION_MODE)
			return;
		Serial.println("PRESS DOWWWNNNN");
		g_mainMenu->print();
        g_mainMenu->action(EMenuAction::DOWN_SINGLE_CLICK_SHORT);
	
	});
	keyboard->addOnSPressedLongFctor([]{
		
		//g_sleepTimer.resetIdleCounter();
		
		if(CALIBRATION_MODE)
			return;
		Serial.println("PRESS S LONG");
		g_mainMenu->action(EMenuAction::S_SINGLE_CLICK_LONG);		
	});
    	keyboard->addOnSPressedFctor([]{
		
		//g_sleepTimer.resetIdleCounter();
		
		if(CALIBRATION_MODE)
			return;
		Serial.println("PRESS S SHORT");
		g_mainMenu->action(EMenuAction::S_SINGLE_CLICK_SHORT);		
	});
	keyboard->addOnRightPressedFctor([]{
		
		//g_sleepTimer.resetIdleCounter();
		
		if(CALIBRATION_MODE)
			return;
		Serial.println("PRESS UP");

		//((CompositeMenu*)g_mainMenu->getCurrentMenu())->moveToNext();	
		g_mainMenu->action(EMenuAction::UP_SINGLE_CLICK_SHORT);		
	});
	
	keyboard->addOnCalibrationComboPressedFctor([]{
		
		g_sleepTimer.resetIdleCounter();
		
		Serial.println("PRESS CALIBRATION");
		
		if(CALIBRATION_MODE)
		{
			Serial.println("WIFI OFF START");
			WiFi.mode(WIFI_OFF);
			while(WiFi.getMode() != WIFI_OFF)
				delay(10);
			Serial.println("WIFI OFF END");
			g_pWebServer->stop();
			Serial.println("g_webServer STOP");
		}

		CALIBRATION_MODE = !CALIBRATION_MODE;		
	});
	
}

void setupPhMeter()
{
	Serial.begin(115200);
	// DEEP-SLEEP init

	//esp_sleep_enable_ext1_wakeup(0x8004, ESP_EXT1_WAKEUP_ANY_HIGH);
	esp_sleep_enable_ext0_wakeup(GPIO_NUM_0, LOW);
	// ADC
	ads1115.begin();
	ads1115.setGain(GAIN_ONE);
	AnalogSourceInput* ads1115AnalogSourceInput = new ADS1115AnalogSourceInput(&ads1115);
    PhSensorDataSource* phSensorDataSource = new PhSensorDataSource(&g_phManager, ads1115AnalogSourceInput);
	// Gas Manager
	

	//	
	/// Menus	
	//
	
	#ifdef USE_SSD1306_DISPLAY
	
	// Display
	display.init();
	display.flipScreenVertically();
	display.setFont(ArialMT_Plain_16);
	
	MenuRenderer* phMenuRenderer = new SSD1306PhMenuRenderer(&display, &g_phManager);	
	MenuRenderer* mvMenuRenderer = new SSD1306MvMenuRenderer(&display, &g_phManager);	
	MenuRenderer* runMenuRenderer = new SSD1306PhRunMenuRenderer(&display, phSensorDataSource, &g_phManager);
    MenuRenderer* calMenuRenderer = new SSD1306PhCalibrationMenuRenderer(&display, phSensorDataSource, &g_phManager);

	MenuRenderer* flashLoggerMenuRenderer = new SSD1306FlashLoggerMenuRenderer(&display, &g_dataLogger);		
	MenuRenderer* wifiDumpMenuRenderer = new SSD1306WiFiDumpMenuRenderer(&display, &g_dataLogger);
	MenuRenderer* wifiRealTimeDumpMenuRenderer = new SSD1306WiFiRealTimeDumpMenuRenderer(&display, &g_dataLogger);
	//MenuRenderer* NTPSyncMenuRenderer = new SSD1306NTPSyncMenuRenderer(&display, &g_timeSync);
	//MenuRenderer* showTimeMenuRenderer = new SSD1306ShowTimeMenuRenderer(&display);
	#endif
	
	#ifdef USE_SSD1327_DISPLAY
	
	// Display
	display.begin();

	MenuRenderer* gasMenuRenderer = new SSD1327GenericMenuWithSelectionRenderer(&display);	
	MenuRenderer* runMenuRenderer = new SSD1327RunMenuRenderer(&display, flowMeterSensorDataSource, &g_gasManager);
    MenuRenderer* calMenuRenderer = new SSD1327CalibrationMenuRenderer(&display, flowMeterSensorDataSource);

	#endif

	vector<MenuWithSelection*> runMenus;
	
	runMenus.push_back(new NoActionMenu("RUN", "RUN", runMenuRenderer));

    runMenus.push_back(new MvMenuItem("MV", "RUN", &g_phManager, mvMenuRenderer));
	runMenus.push_back(new PhMenuItem("PH", "RUN", &g_phManager, phMenuRenderer));
    runMenus.push_back(new CalibrationMenuItem("Calibration", "RUN", &g_phManager, phSensorDataSource, calMenuRenderer));

/*
	// DataLogger Menus
	vector<Menu*> dataLoggerMenus;
	
	dataLoggerMenus.push_back(new DataLoggerFlashStoreMenuItem("FLASH LOGGER", "DATALOGGER", 	&g_dataLogger, flashLoggerMenuRenderer));
	dataLoggerMenus.push_back(new WiFiDumpMenuItem("WIFI DUMP", "DATALOGGER", 				 	&g_dataLogger, wifiDumpMenuRenderer));
	dataLoggerMenus.push_back(new WiFiRealTimeDumpMenuItem("WIFI REAL-TIME DUMP", "DATALOGGER", &g_dataLogger, wifiRealTimeDumpMenuRenderer));
*/	
	
	//CompositeMenu* dataLoggerMenu = new CompositeMenu("DATALOGGER", "Main Menu" , dataLoggerMenus);		
	


////////////////////////////////////	
	vector<Menu*> horizontalMenus;
	
	//horizontalMenus.push_back(runMenu);
	//horizontalMenus.push_back(dataLoggerMenu);

	Serial.println("horizontal menu " + String(horizontalMenus.size())); 
	CompositeMenu* verticalMenu = new CompositeMenu("Main Menu", "", runMenus);
	
	Menu::setMainMenuPtr(verticalMenu);
	
	g_mainMenu = verticalMenu;
	
	g_mainMenu->print();
	
	setupButtons();
	
	g_pWebServer->init(&g_phManager); //, &g_configurationManager);
	//g_sleepTimer.init(&g_configurationManager);
	
	//g_dataLogger.init(phSensorDataSource);
	
	//g_pWebServer->addParamChangeListener((ParamChangeListener*)&g_configurationManager);
	//g_pWebServer->addParamChangeListener((ParamChangeListener*)&g_gasManager);
	
	//g_configurationManager.addParamChangeListener((ParamChangeListener*)&g_timeSync);
	g_configurationManager.addParamChangeListener((ParamChangeListener*)&g_phManager);
    g_phManager.addParamChangeListener((ParamChangeListener*)&g_configurationManager);
	//g_configurationManager.addParamChangeListener((ParamChangeListener*)g_dataLogger.getMqttFlashPublisher());
	//g_configurationManager.addParamChangeListener((ParamChangeListener*)g_dataLogger.getMqttRealTimePublisher());
	
	g_configurationManager.init();
	g_configurationManager.loadFromEEPROM();
	
	//g_timeSync.initTimeFromRTC();

    
	Serial.println("SETUP DONE"); 
}

void loopPhMeter()
{
	ButtonPressDetector::handleTick();

	if(!CALIBRATION_MODE)
	{
		g_mainMenu->render();
	}
	else
	{
		g_sleepTimer.resetIdleCounter();
    
		if(WiFi.getMode() == WIFI_OFF)
		{
			setupWiFi();
		}

		g_pWebServer->handleTick();

		#ifdef USE_SSD1306_DISPLAY
		display.clear();
		display.setColor(WHITE);
		display.setTextAlignment(TEXT_ALIGN_CENTER);
		display.drawString(64, 0,"CALIBRATION MODE");
		display.drawString(64, 20,WiFi.softAPIP().toString().c_str());
		display.display();
		#endif
		
		#ifdef USE_SSD1327_DISPLAY
		display.clearBuffer();
		display.drawStr(64, 0,"CALIBRATION MODE");
		display.drawStr(64, 20,WiFi.softAPIP().toString().c_str());
		display.sendBuffer();
		#endif
		
	} //END IS_CAL IF
	delay(10);
}

/*

#include "phmeter/PhMeterMain.h"


#include <Adafruit_ADS1015.h>
#include <SSD1306.h>
#include <oled.h>

#include <WiFi.h>
#include <vector>

#include "base/TimeSync.h"
#include "phmeter/PhManager.h"
#include "base/Button.h"
#include "base/Menu/Menu.h"
#include "base/Menu/MenuRenderer/MenuRenderer.h"
//#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306RunMenuRenderer.h"
#include "base/Menu/MenuRenderer/SSD1306/SSD1306GenericMenuRenderer.h"


#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306CalibrationMenuRenderer.h"
#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306MvMenuRenderer.h"
#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306PhCalibrationMenuRenderer.h"
#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306PhMenuRenderer.h"
#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306RunMenuRenderer.h"

#include "base/Menu/CompositeMenu.h"
#include "base/SleepTimer.h"
#include "base/Globals.h"
#include "base/DataLogger/DataLogger.h"
#include "base/DataSource/AnalogSourceInput.h"

#include "phmeter/DataSource/PhSensorDataSource.h"

#include "phmeter/WebServer/PhMeterWebServer.h"

using namespace std;


#define USE_SSD1306_DISPLAY
//#define USE_SH1106_DISPLAY

#define MAX_SCCM 5000

#define wifi_ssid "1134ea"
#define wifi_password "DNm11i223344"

PhManager g_phManager;

WebServer* g_pWebServer = new PhMeterWebServer();

CompositeMenu* g_mainMenu = nullptr; 

Adafruit_ADS1115 ads1115;

#ifdef USE_SSD1306_DISPLAY
SSD1306 display(0x3c, 5, 4);
#endif

#ifdef USE_SH1106_DISPLAY
OLED display=OLED(4,5,16);
#endif

SleepTimer g_sleepTimer;

DataLogger g_dataLogger;

TimeSync g_timeSync;

const char* ssid     = "ESP32-Access-Point";
const char* password = "91239";

volatile bool CALIBRATION_MODE = false;

void setupButtons();

void setupWiFi() {
	Serial.print("Setting AP (Access Point)…");
	// Remove the password parameter, if you want the AP (Access Point) to be open
	WiFi.softAP(ssid, password);

	IPAddress IP = WiFi.softAPIP();
	Serial.print("AP IP address: ");
	Serial.println(IP);

	g_pWebServer->begin(80);
}


void setupButtons()
{
	//pinMode(14, INPUT_PULLUP);
	//pinMode(2, INPUT_PULLUP);
	//pinMode(0, INPUT_PULLUP);
	//pinMode(15, INPUT_PULLUP);
	
	Keyboard* keyboard = new Keyboard();
		
	keyboard->addOnDownPressedFctor([]{
		
		g_sleepTimer.resetIdleCounter();
		
		if(CALIBRATION_MODE)
			return;
		Serial.println("PRESS DOWWWNNNN");
		g_mainMenu->print();
		g_mainMenu->moveToPrev();	
	
	});
	keyboard->addOnSPressedLongFctor([]{
		
		g_sleepTimer.resetIdleCounter();
		
		if(CALIBRATION_MODE)
			return;
		Serial.println("PRESS S");
		g_mainMenu->action(EMenuAction::S_SINGLE_CLICK_LONG);		
	});
	keyboard->addOnRightPressedFctor([]{
		
		g_sleepTimer.resetIdleCounter();
		
		if(CALIBRATION_MODE)
			return;
		Serial.println("PRESS RIGHT");

		g_mainMenu->moveToNext();	
		//((CompositeMenu*)g_mainMenu->getCurrentMenu())->moveToNext();	
		g_mainMenu->action(EMenuAction::UP_SINGLE_CLICK_SHORT);		
	});
	
	keyboard->addOnCalibrationComboPressedFctor([]{
		
		g_sleepTimer.resetIdleCounter();
		
		Serial.println("PRESS CALIBRATION");
		
		if(CALIBRATION_MODE)
		{
			Serial.println("WIFI OFF START");
			WiFi.mode(WIFI_OFF);
			while(WiFi.getMode() != WIFI_OFF)
				delay(10);
			Serial.println("WIFI OFF END");
			g_pWebServer->stop();
			Serial.println("g_webServer STOP");
		}

		CALIBRATION_MODE = !CALIBRATION_MODE;		
	});
	
}

void setupPhMeter()
{
	Serial.begin(115200);
	// DEEP-SLEEP init

	//esp_sleep_enable_ext1_wakeup(0x8004, ESP_EXT1_WAKEUP_ANY_HIGH);
	esp_sleep_enable_ext0_wakeup(GPIO_NUM_0, LOW);
	// ADC
	ads1115.begin();
	ads1115.setGain(GAIN_ONE);
	AnalogSourceInput* ads1115AnalogSourceInput = new ADS1115AnalogSourceInput(&ads1115);
	PhSensorDataSource* phSensorDataSource = new PhSensorDataSource(&g_phManager, ads1115AnalogSourceInput);
	//	
	/// Menus	
	//
	
	#ifdef USE_SSD1306_DISPLAY
	
	// Display
	display.init();
	display.flipScreenVertically();
	display.setFont(ArialMT_Plain_16);
	
	//MenuRenderer* gasMenuRenderer = new SSD1306GasMenuRenderer(&display);	
	MenuRenderer* runMenuRenderer = new SSD1306RunMenuRenderer(&display, phSensorDataSource, &g_phManager);
	MenuRenderer* pHMenuRenderer = new SSD1306PhMenuRenderer(&display, &g_phManager);
	MenuRenderer* mVMenuRenderer = new SSD1306MvMenuRenderer(&display, &g_phManager);
	MenuRenderer* calMenuRenderer = new SSD1306CalibrationMenuRenderer(&display);

	MenuRenderer* flashLoggerMenuRenderer = new SSD1306FlashLoggerMenuRenderer(&display, &g_dataLogger);		
	MenuRenderer* wifiDumpMenuRenderer = new SSD1306WiFiDumpMenuRenderer(&display, &g_dataLogger);
	MenuRenderer* wifiRealTimeDumpMenuRenderer = new SSD1306WiFiRealTimeDumpMenuRenderer(&display, &g_dataLogger);
	//MenuRenderer* NTPSyncMenuRenderer = new SSD1306NTPSyncMenuRenderer(&display, &g_timeSync);
	//MenuRenderer* showTimeMenuRenderer = new SSD1306ShowTimeMenuRenderer(&display);
	#endif
	
	#ifdef USE_SH1106_DISPLAY
	
	// Display
	display.begin();

	#endif

	vector<Menu*> runMenus;
	
	runMenus.push_back(new RunMenuItem("RUN", "RUN", &g_phManager, runMenuRenderer));
	runMenus.push_back(new CalibrationMenuItem("MV", "RUN", &g_phManager, phSensorDataSource, calMenuRenderer));
	runMenus.push_back(new PhMenuItem("PH", "RUN", &g_phManager, pHMenuRenderer));
	runMenus.push_back(new MvMenuItem("MV", "RUN", &g_phManager, mVMenuRenderer));
	CompositeMenu* runMenu = new CompositeMenu("RUN", "Main Menu", runMenus);
	
	// DataLogger Menus
	vector<Menu*> dataLoggerMenus;
	
	dataLoggerMenus.push_back(new DataLoggerFlashStoreMenuItem("FLASH LOGGER", "DATALOGGER", 	&g_dataLogger, flashLoggerMenuRenderer));
	dataLoggerMenus.push_back(new WiFiDumpMenuItem("WIFI DUMP", "DATALOGGER", 				 	&g_dataLogger, wifiDumpMenuRenderer));
	dataLoggerMenus.push_back(new WiFiRealTimeDumpMenuItem("WIFI REAL-TIME DUMP", "DATALOGGER", &g_dataLogger, wifiRealTimeDumpMenuRenderer));
	
	
	CompositeMenu* dataLoggerMenu = new CompositeMenu("DATALOGGER", "Main Menu" , dataLoggerMenus);		
	


////////////////////////////////////	
	vector<Menu*> horizontalMenus;
	
	horizontalMenus.push_back(runMenu);
	//horizontalMenus.push_back(dataLoggerMenu);

	Serial.println("horizontal menu " + String(horizontalMenus.size())); 
	CompositeMenu* verticalMenu = new CompositeMenu("Main Menu", "", runMenus);
	
	Menu::setMainMenuPtr(verticalMenu);
	
	g_mainMenu = verticalMenu;
	
	g_mainMenu->print();
	
	setupButtons();
	
	g_pWebServer->init(&g_phManager);
	//g_sleepTimer.init(&g_configurationManager);
	
	g_dataLogger.init(phSensorDataSource);
	
	g_pWebServer->addParamChangeListener((ParamChangeListener*)&g_configurationManager);
	g_pWebServer->addParamChangeListener((ParamChangeListener*)&g_gasManager);
	
	g_configurationManager.addParamChangeListener((ParamChangeListener*)&g_timeSync);
	g_configurationManager.addParamChangeListener((ParamChangeListener*)&g_gasManager);
	g_configurationManager.addParamChangeListener((ParamChangeListener*)g_dataLogger.getMqttFlashPublisher());
	g_configurationManager.addParamChangeListener((ParamChangeListener*)g_dataLogger.getMqttRealTimePublisher());
	
	g_configurationManager.init();
	g_configurationManager.loadFromEEPROM();
	
	g_timeSync.initTimeFromRTC();

}

void loopPhMeter()
{
	ButtonPressDetector::handleTick();
	g_sleepTimer.handleTick();	
	g_dataLogger.handleTick();

	if(!CALIBRATION_MODE)
	{
		g_mainMenu->render();
	}
	else
	{
		g_sleepTimer.resetIdleCounter();
    
		if(WiFi.getMode() == WIFI_OFF)
		{
			setupWiFi();
		}

		g_pWebServer->handleTick();

		#ifdef USE_SSD1306_DISPLAY
		display.clear();
		display.setColor(WHITE);
		display.setTextAlignment(TEXT_ALIGN_CENTER);
		display.drawString(64, 0,"CALIBRATION MODE");
		display.drawString(64, 20,WiFi.softAPIP().toString().c_str());
		display.display();
		#endif
		
		#ifdef USE_SH1106_DISPLAY
		display.draw_string(64, 0,"CALIBRATION MODE");
		display.draw_string(64, 20,WiFi.softAPIP().toString().c_str());
		display.display();
		#endif
		
	} //END IS_CAL IF
	delay(10);
}
*/