#include "flowmeter/Menu/MenuRenderer/SSD1306/SSD1306RunMenuRenderer.h"
#include "flowmeter/DataSource/FlowMeterDataSource.h"
#include "flowmeter/GasManager.h"
#include <SSD1306.h>

SSD1306RunMenuRenderer::SSD1306RunMenuRenderer(SSD1306Wire* display, FlowMeterSensorDataSource* flowMeterDataSource, GasManager* gasManager) : SSD1306MenuRenderer(display),
																														  m_flowMeterDataSource(flowMeterDataSource),
																														  m_gasManager(gasManager)	
{
	
	
}

void SSD1306RunMenuRenderer::render(Menu* menu)
{
	String textToDisplay;

	m_display->clear();
	m_display->setColor(WHITE);
	m_display->setTextAlignment(TEXT_ALIGN_CENTER);

	const float multiplier = 0.125F; //GAIN 1
	
	double sensor_val = m_flowMeterDataSource->getDoubleValue();


	Gas& selectedGas = m_gasManager->getSelectedGas();

	m_display->clear();
	m_display->setColor(WHITE);
	m_display->setTextAlignment(TEXT_ALIGN_CENTER);
	m_display->drawString(64, 0,selectedGas.getName() + " " + String(sensor_val) + "sccm");
	m_display->drawLine(10, 24, 256, 24);
	m_display->drawString(64, 30 ,String( m_flowMeterDataSource->getRawMiliVolts() ) + "mV");
	m_display->display();
	m_display->drawString(64, 30, textToDisplay);
	m_display->display();
}