#include "base/DataSource/DataSource.h"
#include "base/DataSource/AnalogSourceInput.h"


DataSource::DataSource(AnalogSourceInput* analogSourceInput) : m_analogSourceInput(analogSourceInput)
{
    
}

uint16_t DataSource::getRawMiliVolts() const 
{
    return m_analogSourceInput->getMiliVolts();
}

uint16_t DataSource::getMiliVoltsInstant() const
{	
    return m_analogSourceInput->getMiliVoltsInstant();
}