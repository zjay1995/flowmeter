#pragma once

#include "phmeter/PhManager.h"
#include <vector>

#include "base/Globals.h"
#include "phmeter/PhConfigurationManager.h"
#include "base/WebServer/WebServer.h"
#include <WiFi.h>

#define DEBUG_PRINT_ON

class PhMeterWebServer : public WebServer
{

	PhManager* m_phManager;

	PhConfigurationManager* m_configurationManager;

public:

	PhMeterWebServer() : m_phManager(nullptr)
	{
		
		
	}
	
	void init(PhManager* phManager)
	{
		m_phManager = phManager;
	}
	
	void sendHtmlPage(WiFiClient client) {
	
		// HTTP headers always start with a response code (e.g. HTTP/1.1 200 OK)
		// and a content-type so the client knows what's coming, then a blank line:
		client.println("HTTP/1.1 200 OK");
		client.println("Content-type:text/html");
		client.println("Connection: close");
		client.println();							
		// Display the HTML web page
		client.println("<!DOCTYPE html><html>");
		client.println("<head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
		client.println("<link rel=\"icon\" href=\"data:,\">");
		// CSS to style the on/off buttons 
		// Feel free to change the background-color and font-size attributes to fit your preferences
		client.println("<style>html { font-family: Helvetica; display: inline-block; margin: 0px auto; text-align: center;}");
		client.println(".button { background-color: #4CAF50; border: none; color: white; padding: 16px 40px;");
		client.println("text-decoration: none; font-size: 30px; margin: 2px; cursor: pointer;}");
		client.println(".button2 {background-color: #555555;}</style></head>");
		
		// Web Page Heading
		client.println("<body><h1>ESP32 Web Server</h1>");
		
		client.println("<form action=\"/\">");
		
		client.println("<hr style=\"height:2px;border-width:0;color:gray;background-color:gray\">");
		client.println("<label for=\"fname\">Buffers:</label><br>");
		client.println("<label for=\"fname\">Buffer 1 (pH 4.01):</label>");
		client.println("<input type=\"text\" id=\"buffer1mv\" name=\"buffer1mv\" value=\"" + String(m_phManager->getBuffer1Mv()) + "\"></p>");
		client.println("<label for=\"fname\">Buffer 2 (pH 7.01):</label>");
		client.println("<input type=\"text\" id=\"buffer1mv\" name=\"buffer2mv\" value=\"" + String(m_phManager->getBuffer2Mv()) + "\"><br>");
		
/*	
		for(int i = 0; i < gases.size(); i++)
		{
			client.println("<hr style=\"height:2px;border-width:0;color:gray;background-color:gray\">");
			client.println("<label for=\"fname\">" + gases[i].getName() + "</label><br>");
			client.println("<label for=\"fname\">Thermal conductivity::</label>");
			client.println("<input type=\"text\" id=\"tc" + String(i) + "\" name=\"" + gases[i].getName() + "\" value=\"" + String(gases[i].getThermalConductivity(), 6) + "\"></p>");
		}
*/
		client.println("<hr style=\"height:2px;border-width:0;color:gray;background-color:gray\">");
		client.println("<label for=\"fname\">WiFi credentials:</label><br>");
		client.println("<label for=\"fname\">SSID:</label>");
		client.println("<input type=\"text\"name=\"" + String(c_WIFI_SSID_PARAM_NAME) + "\" value=\"" + m_configurationManager->getWifiSsid() + "\"></p>");
		client.println("<label for=\"fname\">PASSWORD:</label>");
		client.println("<input type=\"text\" name=\"" + String(c_WIFI_PASSWORD_PARAM_NAME) + "\" value=\"" + m_configurationManager->getWifiPassword() + "\"><br>");

		client.println("<input type=\"submit\" value=\"Modify\" method=\"GET\">");
		client.println("</form>");

		client.println("</body></html>");
		// The HTTP response ends with another blank line
		client.println();
	}
};