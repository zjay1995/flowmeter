#pragma once

#include "base/DataLogger/RecordManager.h"
#include "phmeter/DataSource/PhSensorDataSource.h"

#include <SPIFFS.h>

class PhSensorRecordManager : public RecordManager
{


public:

    String  readRecordAsJson(File* file)
    {


        return String("");
    }
    
    bool    writeRecordToFile(DataSource* dataSource, File* pFile)
    {
        PhSensorDataSource* phSensorDataSource = (PhSensorDataSource*)dataSource;
        
        double ph = phSensorDataSource->getDoubleValue();

        if (pFile->write((const uint8_t*)&ph, sizeof(double)) != sizeof(double))
        {
            Serial.println("handleTick:: can't write to file with name:" + String(pFile->name()));
            return false;
        }

        return true;
    }
};