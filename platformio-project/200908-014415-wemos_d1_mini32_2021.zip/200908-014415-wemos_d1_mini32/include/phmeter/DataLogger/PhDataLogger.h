#pragma once

#include <SPIFFS.h>

#include <time.h>
#include <sys/time.h>

#include "base/DataLogger/DataLogger.h"

class PhManager;
class DataSource;

class MQTTFlashPublisher;
class MQTTRealTimePublisher;

class PhDataLogger : public DataLogger
{
	String createFileName(String ts, String name, int secondsBetweenDataPoints, int fileIndex);

public:

	PhDataLogger()=default;
	~PhDataLogger()=default;
	

	void init(DataSource* phSensorDataSource, PhManager* phManager);

};