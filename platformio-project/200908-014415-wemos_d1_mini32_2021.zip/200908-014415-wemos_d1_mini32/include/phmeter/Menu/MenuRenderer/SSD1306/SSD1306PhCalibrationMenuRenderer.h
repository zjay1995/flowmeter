#pragma once

#include "base/Menu/MenuRenderer/MenuRenderer.h"
#include "base/Menu/MenuRenderer/SSD1306/SSDGenericMenuWithSelectionRenderer.h"

class SSD1306MenuRenderer;
class PhSensorDataSource;
class PhManager;

class SSD1306PhCalibrationMenuRenderer : public SSD1306MenuRenderer
{
	
	PhSensorDataSource* m_phSensorDataSource;
	PhManager*			m_phManager;

public:

	SSD1306PhCalibrationMenuRenderer(SSD1306Wire* display, PhSensorDataSource* phSensorDataSource, PhManager* phManager);

	void render(Menu* menu);
};