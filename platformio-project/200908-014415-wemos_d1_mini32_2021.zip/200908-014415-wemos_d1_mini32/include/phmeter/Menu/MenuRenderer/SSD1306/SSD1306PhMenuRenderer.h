#pragma once

#include "base/Menu/MenuRenderer/MenuRenderer.h"

class PhSensorDataSource;
class PhManager;

class SSD1306PhMenuRenderer : public SSD1306MenuRenderer
{
	PhManager*			m_phManager;
	
public:

	SSD1306PhMenuRenderer(SSD1306Wire* display, PhManager* phManager);

	void render(Menu* menu);
};