#include "base/Menu/Menu.h"
#include "phmeter/PhManager.h"


class MvMenuItem : public MenuWithSelection 
{
	PhManager* m_phManager;
	
public:	

	MvMenuItem(String name, String parentName, PhManager* phManager, MenuRenderer* renderer) : MenuWithSelection(name, parentName, renderer),
                                                                                                   m_phManager(phManager)
	{
		
	}

	void action(EMenuAction eMenuAction)
	{
		Serial.println("MvMenuItem action");
        if(eMenuAction == EMenuAction::S_SINGLE_CLICK_LONG)
        {
		    m_phManager->setItemOfInterest(EItemOfInterest::MV);	
			Menu::exitToRunMenu();
        }
	}
	
};