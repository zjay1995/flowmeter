#pragma once

#include "base/DataSource/AnalogSourceInput.h"
#include "phmeter/PhManager.h"
#include "base/DataSource/DataSource.h"

class PhSensorDataSource : public DataSource
{
	PhManager* 			m_phManager;
	
public:

	PhSensorDataSource(PhManager* phManager, AnalogSourceInput* analogSourceInput) : DataSource(analogSourceInput),
																					 m_phManager(phManager)
	{
		
	}
	~PhSensorDataSource()=default;

	double getDoubleValue()
	{
		uint16_t miliVolts = m_analogSourceInput->getMiliVolts();
		return m_phManager->calculatePh(miliVolts);
	}	

	double getDoubleValue(uint16_t mv)
	{
		return m_phManager->calculatePh(mv);
	}
	

};


