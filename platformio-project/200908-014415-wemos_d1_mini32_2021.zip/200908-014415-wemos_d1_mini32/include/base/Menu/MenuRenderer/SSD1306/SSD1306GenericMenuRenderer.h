#pragma once

#include "base/Menu/MenuRenderer/MenuRenderer.h"

#include <Arduino.h>


class SSD1306GenericMenuRenderer : public SSD1306MenuRenderer
{
protected:
    String m_text;

public:

    SSD1306GenericMenuRenderer(SSD1306Wire* display, String text);

    virtual void render(Menu* menu);
};
