#pragma once

#include "flowmeter/GasManager.h"
#include "base/SleepTimer.h"
#include "base/DataLogger/DataLogger.h"
#include "base/TimeSync.h"

enum EMenuAction
{
	S_SINGLE_CLICK_SHORT = 0,
	UP_SINGLE_CLICK_SHORT,
	DOWN_SINGLE_CLICK_SHORT,
	S_SINGLE_CLICK_LONG,
	UP_SINGLE_CLICK_LONG,
	DOWN_SINGLE_CLICK_LONG
};

class CompositeMenu;
class MenuRenderer;

class Menu 
{
protected:

	String m_menuName;
	String m_parentMenuName;
	
	MenuRenderer* m_menuRenderer;

	static CompositeMenu* s_mainMenu;

	// Rendered at bottom
	String m_infoMessage;

	unsigned long m_infoMessageSetTimestamp = 0;

	int m_infoMessageDurationMillis = 3000;

public:
	
	Menu(String name, String parentName, MenuRenderer* renderer);
	
	virtual ~Menu() = default;
	
	
	String getName();
	String getParentName();
	
	void setInfoMessage(String message, unsigned long durationMillis = 3000)
	{ 
		m_infoMessage = message;
		m_infoMessageSetTimestamp = millis();
	}
	
	String getInfoMessage() 
	{
		if(millis() - m_infoMessageSetTimestamp >= m_infoMessageDurationMillis)
		{
			m_infoMessage = "";
			m_infoMessageSetTimestamp = 0;
		}	

		return m_infoMessage; 
	};


	virtual void action(EMenuAction eMenuAction) = 0;
	
	virtual void render();

	static void setMainMenuPtr(Menu* mainMenu);
	static void exitToRunMenu();
	static void doRender();
	
};

class MenuSelectionItem
{
	String m_internalName;
	String m_displayName;

public:

	MenuSelectionItem(String internalName, String displayName) : m_internalName(internalName),
																 m_displayName(displayName)
	{



	}

	String getInternalName() const { return m_internalName; }
	String getDisplayName()  const { return m_displayName;  }

};


class MenuWithSelection : public Menu
{

protected:

	std::vector<MenuSelectionItem> m_selectionItems;
	int m_selectedItemIndex = 0;
	bool m_selectionModeActive = false;

public:

	MenuWithSelection(String name, String parentName, std::vector<MenuSelectionItem>& menuSelectionItems, MenuRenderer* renderer) : Menu(name, parentName, renderer),
																															   m_selectionItems(menuSelectionItems)
	{


	}

	MenuWithSelection(String name, String parentName, MenuRenderer* renderer) : Menu(name, parentName, renderer)
	{


	}

	virtual ~MenuWithSelection() = default;


	bool isSelectionModeActive() const { return m_selectionModeActive; }

	void setSelectionItems(std::vector<MenuSelectionItem>& menuSelectionItems)
	{
		m_selectionItems = menuSelectionItems;
	}

	const std::vector<MenuSelectionItem>& getSelectionItems() const { return m_selectionItems; }

	const MenuSelectionItem getSelectionItem() const { return m_selectionItems[m_selectedItemIndex]; }

	virtual void selectNext()
	{
		m_selectedItemIndex = (m_selectedItemIndex + 1) % m_selectionItems.size();
	}
	
	virtual void selectPrevious()
	{
		if(m_selectedItemIndex == 0)
			m_selectedItemIndex = m_selectionItems.size() - 1;
		else
			m_selectedItemIndex = m_selectedItemIndex - 1;
	}

	virtual void action(EMenuAction eMenuAction)
	{
		if(eMenuAction == EMenuAction::S_SINGLE_CLICK_SHORT || eMenuAction == EMenuAction::S_SINGLE_CLICK_LONG)
		{
			Serial.println("MenuWithSelection action S");
			m_selectionModeActive = !m_selectionModeActive;
		}
		else if(eMenuAction == EMenuAction::UP_SINGLE_CLICK_SHORT && m_selectionModeActive)
		{
			Serial.println("MenuWithSelection action UP");
			selectNext();
		}
		else if(eMenuAction == EMenuAction::DOWN_SINGLE_CLICK_SHORT && m_selectionModeActive)
		{
			Serial.println("MenuWithSelection action DOWN");
			selectPrevious();
		}
	}

};

class NoActionMenu : public MenuWithSelection
{
public:

	NoActionMenu(String name, String parentName, MenuRenderer* renderer) : MenuWithSelection(name, parentName, renderer)
	{


	}

	void action(EMenuAction eMenuAction)
	{
		/*
			NO ACTION
		*/
	}


};