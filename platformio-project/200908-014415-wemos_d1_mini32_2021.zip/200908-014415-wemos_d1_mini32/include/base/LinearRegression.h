#pragma once

#include <algorithm>
#include <numeric>
#include <vector>


class LinearRegression
{

    double m_intercept;
    double m_slope;

public:


    LinearRegression() = default;
    ~LinearRegression() = default;
    

    void calculateInterceptAndSlope(const std::vector<double>& x, const std::vector<double>& y)
    {
        const auto n = x.size();
        const auto s_x = std::accumulate(x.begin(), x.end(), 0.0);
        const auto s_y = std::accumulate(y.begin(), y.end(), 0.0);
        const auto s_xx = std::inner_product(x.begin(), x.end(), x.begin(), 0.0);
        const auto s_xy = std::inner_product(x.begin(), x.end(), y.begin(), 0.0);

        m_slope     = (n * s_xy - s_x * s_y)    /   (n * s_xx - s_x * s_x); 
        m_intercept = (s_y * s_xx - s_x* s_xy)  /   (n * s_xx - s_x * s_x);
    }

    double calculateYforX(double X)
    {
		double val = (m_slope * X + m_intercept);
		return val < 0 ? 0 : val;
    }


    double getIntercept() const { return m_intercept; }
    double getSlope()     const { return m_slope;     }

};

