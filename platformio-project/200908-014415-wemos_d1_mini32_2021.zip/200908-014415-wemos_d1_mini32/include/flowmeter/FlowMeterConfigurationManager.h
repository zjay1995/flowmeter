#pragma once

#include <Arduino.h>

#include "base/ParamChangeListener.h"

class SleepTimer;
class GasManager;
class ParamChangeListener;


class FlowMeterConfigurationManager : public ParamChangeListener
{
	
const uint16_t EEPROM_SIZE = sizeof(int) + 				// TIMER
							sizeof(double) * (2 + 8)	// GASES
							+ 200;
	
const uint16_t EEPROM_TIMER_OFFSET = 0;
const uint16_t EEPROM_DEVICE_ID_OFFSET = 4;			//64 chars
const uint16_t EEPROM_WIFI_SSID_OFFSET = 68;			//32 chars
const uint16_t EEPROM_WIFI_PASSWORD_OFFSET = 100;	//32 chars
const uint16_t EEPROM_MQTT_SERVER_URL_OFFSET = 132;	//64 chars
const uint16_t EEPROM_FLASH_LOG_FREQ_OFFSET = 196;	//uint16_t
const uint16_t EEPROM_WIFI_RT_LOG_FREQ_OFFSET = 198;	//uint16_t
const uint16_t EEPROM_00_SLM_MV_OFFSET = 200;
const uint16_t EEPROM_05_SLM_MV_OFFSET = 202;
const uint16_t EEPROM_10_SLM_MV_OFFSET = 204;
const uint16_t EEPROM_15_SLM_MV_OFFSET = 206;
const uint16_t EEPROM_20_SLM_MV_OFFSET = 208;
const uint16_t EEPROM_25_SLM_MV_OFFSET = 210;


	bool m_loadAllInProgress = false;

	std::vector<ParamChangeListener*> m_paramChangeListeners;

	String m_wifiSsid;
	String m_wifiPassword;
	String m_deviceId;
	uint16_t m_wifiRtLogFreq;
	uint16_t m_flashLogFreq;
	String m_mqttServerUrl;


	uint16_t m_00SlmMv;
	uint16_t m_05SlmMv;
	uint16_t m_10SlmMv;
	uint16_t m_15SlmMv;
	uint16_t m_20SlmMv;
	uint16_t m_25SlmMv;

public:

	FlowMeterConfigurationManager();
	
	void init();
	
	void loadFromEEPROM();
		
	void saveTimerIntervalToEEPROM(int interval, bool doCommit = true);
	void saveWifiSSID(String ssid, bool doCommit = true);
	void saveWifiPassword(String password, bool doCommit = true);
	void saveMqttServerUrl(String url, bool doCommit = true);
	void saveFlashLogFrequency(uint16_t freq, bool doCommit = true);
	void saveWifiRtLogFrequency(uint16_t freq, bool doCommit = true);
	void saveDeviceId(String id, bool doCommit = true);

	// Getters
	String getWifiSsid() const { return m_wifiSsid; }
	String getWifiPassword() const { return m_wifiPassword; }
	String getDeviceId() const { return m_deviceId; }
	String getWifiRtLogFreqAsString() const { return String(m_wifiRtLogFreq); }
	String getFlashLogFreqAsString() const { return String(m_flashLogFreq); }
	String getMqttServerUrl() const { return m_mqttServerUrl; }


	void setupEEPROM();
	
	void clearEEPROM();

	void onParamChange(String param, String value);


	void addParamChangeListener(ParamChangeListener* l);
	void notifyParamChanged(String param, String value);

};