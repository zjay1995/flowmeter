#pragma once

#include "base/Menu/Menu.h"
#include "flowmeter/GasManager.h"
#include "flowmeter/DataSource/FlowMeterDataSource.h"

enum ECalibrationType
{
	TWO_POINT_CALIBRATION = 0,
	THREE_POINT_CALIBRATION
};

class FlowMeterCalibrationMenuItem : public MenuWithSelection
{
	GasManager*			m_gasManager;
	
	FlowMeterSensorDataSource*	m_flowMeterSensorDataSource;

	bool m_calibrationRunning = false;

public:	

	FlowMeterCalibrationMenuItem(String name, String parentName, GasManager* gasManager, FlowMeterSensorDataSource* flowMeterSensorDataSource, MenuRenderer* renderer) : MenuWithSelection(name, parentName, renderer),
                                                                                                   														 				 m_gasManager(gasManager),
																																						 				 m_flowMeterSensorDataSource(flowMeterSensorDataSource)
	{							
		std::vector<MenuSelectionItem> selectionMenuItems;

		selectionMenuItems.push_back(MenuSelectionItem("0SLM", 	 "0 SLM"	));
		selectionMenuItems.push_back(MenuSelectionItem("0.5SLM", "0.5 SLM"	));
		selectionMenuItems.push_back(MenuSelectionItem("1.0SLM", "1.0 SLM"	));
		selectionMenuItems.push_back(MenuSelectionItem("1.5SLM", "1.5 SLM"	));
		selectionMenuItems.push_back(MenuSelectionItem("2.0SLM", "2.0 SLM"	));
		selectionMenuItems.push_back(MenuSelectionItem("2.5SLM", "2.5 SLM"	));

		setSelectionItems(selectionMenuItems);
	}

	void action(EMenuAction eMenuAction)
	{
		MenuWithSelection::action(eMenuAction);

		Serial.println("FlowMeterCalibrationMenuItem action: " + getSelectionItem().getInternalName());

        if(eMenuAction != EMenuAction::S_SINGLE_CLICK_LONG)
			return;

		m_calibrationRunning = true;

		setInfoMessage("Calibrating...");

		Menu::doRender();

		vTaskDelay(1000);

		int sum = 0;
		for(int i = 0; i < 20; i++)
			sum += m_flowMeterSensorDataSource->getMiliVoltsInstant();

		double avg = sum / 20.0;

		int16_t mv = (int16_t)round(avg);

		MenuSelectionItem selectedItem = getSelectionItem();

		if(selectedItem.getInternalName().equals("0SLM"))
			m_gasManager->setMilivoltsReading(mv, 0);
		else if(selectedItem.getInternalName().equals("0.5SLM"))
			m_gasManager->setMilivoltsReading(mv, 1);
		else if(selectedItem.getInternalName().equals("1.0SLM"))
			m_gasManager->setMilivoltsReading(mv, 2);
		else if(selectedItem.getInternalName().equals("1.5SLM"))
			m_gasManager->setMilivoltsReading(mv, 3);
		else if(selectedItem.getInternalName().equals("2.0SLM"))
			m_gasManager->setMilivoltsReading(mv, 4);
		else if(selectedItem.getInternalName().equals("2.5SLM"))
			m_gasManager->setMilivoltsReading(mv, 5);
			
		setInfoMessage(selectedItem.getDisplayName() + ":" + String(mv));

		m_calibrationRunning = false;
		//Menu::exitToRunMenu();
	}

	String getInfoMessage() const 	{ return m_infoMessage; 	   }

	bool calibrationRunning() const { return m_calibrationRunning; }
	
};