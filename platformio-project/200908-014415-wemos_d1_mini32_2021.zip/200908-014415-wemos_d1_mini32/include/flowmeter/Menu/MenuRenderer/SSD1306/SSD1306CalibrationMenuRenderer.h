#pragma once

#include "base/Menu/MenuRenderer/MenuRenderer.h"

class SSD1306MenuRenderer;
class SSD1306Wire;
class FlowMeterSensorDataSource;

class SSD1306CalibrationMenuRenderer : public SSD1306MenuRenderer
{
	
	FlowMeterSensorDataSource* m_flowMeterSensorDataSource;

public:

	SSD1306CalibrationMenuRenderer(SSD1306Wire* display, FlowMeterSensorDataSource* flowMeterSensorDataSource);

	void render(Menu* menu);
};