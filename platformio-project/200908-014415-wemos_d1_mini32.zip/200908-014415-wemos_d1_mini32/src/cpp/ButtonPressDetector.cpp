#include "base/Button.h"

std::vector<ButtonPressDetector*> ButtonPressDetector::s_ButtonPressDetectors;