#include "phmeter/Menu/MenuRenderer/SSD1306/SSD1306PhRunMenuRenderer.h"
#include "phmeter/DataSource/PhSensorDataSource.h"
#include "phmeter/PhManager.h"
#include <SSD1306.h>

SSD1306PhRunMenuRenderer::SSD1306PhRunMenuRenderer(SSD1306Wire* display, PhSensorDataSource* phSensorDataSource, PhManager* phManager) : SSD1306MenuRenderer(display),
																														  m_phSensorDataSource(phSensorDataSource),
																														  m_phManager(phManager)	
{
	
	
}

void SSD1306PhRunMenuRenderer::render(Menu* menu)
{
	String textToDisplay;

	m_display->clear();
	m_display->setColor(WHITE);
	m_display->setTextAlignment(TEXT_ALIGN_CENTER);

	if(m_phManager->getItemOfInterest() == EItemOfInterest::PH)
	{
		textToDisplay = "pH: " + String(m_phSensorDataSource->getDoubleValue(), 3);
	}
	else if(m_phManager->getItemOfInterest() == EItemOfInterest::MV)
	{
		textToDisplay = "mV: " + String(m_phSensorDataSource->getRawMiliVolts());
	}

	m_display->drawString(64, 30, textToDisplay);
	m_display->display();
}

