#include "phmeter/PhManager.h"
#include "base/Globals.h"

PhManager::PhManager()
{
    m_eItemOfInterest = EItemOfInterest::PH;
    m_buffer1Mv = 1;
    m_buffer2Mv = 1;
    m_buffer3Mv = 1;
/*
    const uint16_t c_BUFFER_1_HI_BOUND_MV = 3500;
    const uint16_t c_BUFFER_2_HI_BOUND_MV = 2950;
    const uint16_t c_BUFFER_3_HI_BOUND_MV = 2000;
*/



}

void PhManager::setItemOfInterest(EItemOfInterest eItemOfInterest)
{
        m_eItemOfInterest = eItemOfInterest;

        
}






EItemOfInterest PhManager::getItemOfInterest() const 
{
     return m_eItemOfInterest; 
}


double PhManager::calculatePh(int miliVolts)
{
    float ph = 0.0;

    if(miliVolts > 0 && miliVolts <= m_buffer3Mv)
    {
        ph = (m_buffer3Mv / (0 + miliVolts)) * c_BUFFER_3_PH_VAL;
    }
    else if(m_buffer3Mv > 0 && miliVolts <= m_buffer2Mv)
    {
        ph = c_BUFFER_2_PH_VAL + ((m_buffer2Mv - m_buffer3Mv) / (miliVolts - m_buffer3Mv)) * (c_BUFFER_3_PH_VAL - c_BUFFER_2_PH_VAL);
    }
    else if(miliVolts > m_buffer2Mv && miliVolts <= m_buffer1Mv)
    {
        ph = c_BUFFER_1_PH_VAL + ((m_buffer1Mv - m_buffer2Mv) / (miliVolts - m_buffer2Mv)) * (c_BUFFER_2_PH_VAL - c_BUFFER_1_PH_VAL);
    }
    else if(miliVolts > m_buffer1Mv)
    {
        ph = c_BUFFER_2_PH_VAL + ((m_buffer2Mv - m_buffer3Mv) / (miliVolts - m_buffer1Mv)) * (c_BUFFER_3_PH_VAL - c_BUFFER_2_PH_VAL);
    }

    return ph;

}

void PhManager::setBuffer1Mv(uint16_t val)
{
    m_buffer1Mv = val;
}

void PhManager::setBuffer2Mv(uint16_t val)
{
    m_buffer2Mv = val;
}

void PhManager::setBuffer3Mv(uint16_t val)
{
    m_buffer3Mv = val;
}

bool PhManager::isInBuffer1Range(uint16_t mv) const { return mv >= c_BUFFER_1_LO_BOUND_MV && mv <= c_BUFFER_1_HI_BOUND_MV; }
bool PhManager::isInBuffer2Range(uint16_t mv) const { return mv >= c_BUFFER_2_LO_BOUND_MV && mv <= c_BUFFER_2_HI_BOUND_MV; }
bool PhManager::isInBuffer3Range(uint16_t mv) const { return mv >= c_BUFFER_3_LO_BOUND_MV && mv <= c_BUFFER_3_HI_BOUND_MV; }

void PhManager::onParamChange(String param, String value)
{
    Serial.println("PhManager::onParamChange: " + param + "=" + value);
    
    if(param.equals(c_BUFFER_1_MV_PARAM_NAME))
    {
        Serial.println("Setting c_BUFFER_1_MV_PARAM_NAME: " + value);
        m_buffer1Mv = value.toInt();
    }
    else if(param.equals(c_BUFFER_2_MV_PARAM_NAME))
    {
        Serial.println("Setting c_BUFFER_2_MV_PARAM_NAME: " + value);
        m_buffer2Mv = value.toInt();
    }
    else if(param.equals(c_BUFFER_3_MV_PARAM_NAME))
    {
        Serial.println("Setting c_BUFFER_3_MV_PARAM_NAME: " + value);
        m_buffer3Mv = value.toInt();
    }

}