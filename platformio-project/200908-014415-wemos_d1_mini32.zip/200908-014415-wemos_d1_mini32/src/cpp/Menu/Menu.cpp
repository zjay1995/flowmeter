#include "base/Menu/Menu.h"
#include "base/Menu/CompositeMenu.h"
#include "base/Menu/MenuRenderer/MenuRenderer.h"

CompositeMenu* Menu::s_mainMenu = nullptr;


Menu::Menu(String name, String parentName, MenuRenderer* renderer) : m_menuName(name),
                                                                     m_parentMenuName(parentName),
                                                                     m_menuRenderer(renderer)
{
    
}


String Menu::getName()       { return m_menuName; }
String Menu::getParentName() { return m_parentMenuName; }

void Menu::render()
{
    m_menuRenderer->render(this);
}

void Menu::setMainMenuPtr(Menu* mainMenu)
{
    s_mainMenu = (CompositeMenu*)mainMenu;
}

void Menu::exitToRunMenu()
{
    s_mainMenu->moveToFirst();
}

void Menu::doRender()
{
    s_mainMenu->render();
}