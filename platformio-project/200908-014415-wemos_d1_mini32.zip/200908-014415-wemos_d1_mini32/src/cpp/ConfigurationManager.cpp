#include "phmeter/PhConfigurationManager.h"
#include <EEPROM.h>

#include "base/Globals.h"

PhConfigurationManager::PhConfigurationManager()
{

}

void PhConfigurationManager::init()
{
	setupEEPROM();
}

void PhConfigurationManager::loadFromEEPROM()
{
	m_loadAllInProgress = true;
	
	int timerInterval = EEPROM.readInt(EEPROM_TIMER_OFFSET);
	Serial.println("config: timer interval: " + String(timerInterval));
	
	//m_sleepTimer->selectIntervalByValue( timerInterval );	
			
	// BUFFERS

	// 1
	uint16_t buffer1Mv = EEPROM.readUShort(EEPROM_BUFFER_1_MV_OFFSET);
	if (buffer1Mv > 0)
		notifyParamChanged(c_BUFFER_1_MV_PARAM_NAME, String(buffer1Mv));
	Serial.println("config: c_BUFFER_1_MV_PARAM_NAME: " + String(buffer1Mv));
	m_buffer1Mv = buffer1Mv;
	// 2
	uint16_t buffer2Mv = EEPROM.readUShort(EEPROM_BUFFER_2_MV_OFFSET);
	if (buffer2Mv > 0)
		notifyParamChanged(c_BUFFER_2_MV_PARAM_NAME, String(buffer2Mv));
	Serial.println("config: c_BUFFER_2_MV_PARAM_NAME: " + String(buffer2Mv));
	m_buffer2Mv = buffer2Mv;
	// 3
	uint16_t buffer3Mv = EEPROM.readUShort(EEPROM_BUFFER_3_MV_OFFSET);
	if (buffer3Mv > 0)
		notifyParamChanged(c_BUFFER_3_MV_PARAM_NAME, String(buffer3Mv));
	Serial.println("config: c_BUFFER_3_MV_PARAM_NAME: " + String(buffer3Mv));
	m_buffer3Mv = buffer3Mv;
	
	///////////////

	// WiFi SSID
	char wifiSsid[32] = { 0 };
	size_t readSsid = EEPROM.readString(EEPROM_WIFI_SSID_OFFSET, wifiSsid, 31);
	if (readSsid > 0)
		notifyParamChanged(c_WIFI_SSID_PARAM_NAME, String(wifiSsid));
	Serial.println("config: WiFi SSID: " + String(wifiSsid));
	m_wifiSsid = wifiSsid;

	// WiFi PASSWORD
	char wifiPsw[32] = { 0 };
	size_t readPsw = EEPROM.readString(EEPROM_WIFI_PASSWORD_OFFSET, wifiPsw, 31);
	if (readPsw > 0)
		notifyParamChanged(c_WIFI_PASSWORD_PARAM_NAME, String(wifiPsw));
	Serial.println("config: WiFi PSW: " + String(wifiPsw));
	m_wifiPassword = wifiPsw;

	// MQTT SERVER URL
	char mqttUrl[64] = { 0 };
	size_t readUrl = EEPROM.readString(EEPROM_MQTT_SERVER_URL_OFFSET, mqttUrl, 63);
	if (readUrl > 0)
		notifyParamChanged(c_MQTT_SERVER_URL_PARAM_NAME, String(mqttUrl));
	Serial.println("config: MQTT SERVER URL: " + String(mqttUrl));
	m_mqttServerUrl = mqttUrl;

	// FLASH LOG FREQUENCY
	uint16_t flashLogFreq = EEPROM.readUShort(EEPROM_FLASH_LOG_FREQ_OFFSET);
	if (flashLogFreq > 0)
		notifyParamChanged(c_MQTT_SERVER_URL_PARAM_NAME, String(flashLogFreq));
	Serial.println("config: FLASH LOG FREQUENCY: " + String(flashLogFreq));
	m_flashLogFreq = flashLogFreq;

	// WIFI RT LOG FREQUENCY
	uint16_t wifiRtLogFreq = EEPROM.readUShort(EEPROM_WIFI_RT_LOG_FREQ_OFFSET);
	if (wifiRtLogFreq > 0)
		notifyParamChanged(c_MQTT_SERVER_URL_PARAM_NAME, String(wifiRtLogFreq));
	Serial.println("config: WIFI RT LOG FREQUENCY: " + String(wifiRtLogFreq));
	m_wifiRtLogFreq = wifiRtLogFreq;

	/////////////////

	m_loadAllInProgress = false;

	return;		
}

void PhConfigurationManager::addParamChangeListener(ParamChangeListener* l)
{
	m_paramChangeListeners.push_back(l);
}

void PhConfigurationManager::notifyParamChanged(String param, String value)
{
	for (auto& l : m_paramChangeListeners)
		l->onParamChange(param, value);
}

void PhConfigurationManager::onParamChange(String param, String value)
{
	if (param.equals(c_FLASH_LOG_FREQ_PARAM_NAME))
	{
		Serial.println("EEPROM save c_FLASH_LOG_FREQ_PARAM_NAME: " + value);
		EEPROM.writeUShort(EEPROM_FLASH_LOG_FREQ_OFFSET, value.toInt());

		m_flashLogFreq = value.toInt();
	}
	else if (param.equals(c_WIFI_RT_LOG_FREQ_PARAM_NAME))
	{
		Serial.println("EEPROM save c_WIFI_RT_LOG_FREQ_PARAM_NAME: " + value);
		EEPROM.writeUShort(EEPROM_WIFI_RT_LOG_FREQ_OFFSET, value.toInt());

		m_wifiRtLogFreq = value.toInt();
	}
	else if (param.equals(c_WIFI_SSID_PARAM_NAME))
	{
		size_t ret = EEPROM.writeString(EEPROM_WIFI_SSID_OFFSET, value.c_str());
		Serial.println("EEPROM save c_WIFI_SSID_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_wifiSsid = value;
	}
	else if (param.equals(c_WIFI_PASSWORD_PARAM_NAME))
	{
		size_t ret = EEPROM.writeString(EEPROM_WIFI_PASSWORD_OFFSET, value.c_str());
		Serial.println("EEPROM save c_WIFI_PASSWORD_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_wifiPassword = value;
	}
	else if (param.equals(c_BUFFER_1_MV_PARAM_NAME))
	{
		size_t ret = EEPROM.writeUShort(EEPROM_BUFFER_1_MV_OFFSET, value.toInt());
		Serial.println("EEPROM save c_BUFFER_1_MV_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_buffer1Mv = value.toInt();
	}
	else if (param.equals(c_BUFFER_2_MV_PARAM_NAME))
	{
		size_t ret = EEPROM.writeUShort(EEPROM_BUFFER_2_MV_OFFSET, value.toInt());
		Serial.println("EEPROM save c_BUFFER_2_MV_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_buffer2Mv = value.toInt();
	}
	else if (param.equals(c_BUFFER_3_MV_PARAM_NAME))
	{
		size_t ret = EEPROM.writeUShort(EEPROM_BUFFER_3_MV_OFFSET, value.toInt());
		Serial.println("EEPROM save c_BUFFER_3_MV_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_buffer3Mv = value.toInt();
	}
	if (!EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");

	// This is WebServer changing params so notify others too!
	notifyParamChanged(param, value);
}

void PhConfigurationManager::saveTimerIntervalToEEPROM(int interval, bool doCommit)
{	
	if(m_loadAllInProgress)
		return;
	Serial.println("EEPROM saveTimerIntervalToEEPROM: " + String(interval));
	size_t written = EEPROM.put(0, interval);
	Serial.println("EEPROM written: " + String(written));
	if(doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}			

void PhConfigurationManager::saveWifiSSID(String ssid, bool doCommit)
{
	if (m_loadAllInProgress)
		return;
	Serial.println("EEPROM saveWifiSSID: " + ssid);
	size_t written = EEPROM.writeString(EEPROM_WIFI_SSID_OFFSET, ssid.c_str());
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void PhConfigurationManager::saveWifiPassword(String password, bool doCommit)
{
	if (m_loadAllInProgress)
		return;
	Serial.println("EEPROM saveWifiPassword: " + password);
	size_t written = EEPROM.writeString(EEPROM_WIFI_PASSWORD_OFFSET, password.c_str());
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void PhConfigurationManager::saveMqttServerUrl(String url, bool doCommit)
{
	if (m_loadAllInProgress)
		return;
	Serial.println("EEPROM saveMqttServerUrl: " + url);
	size_t written = EEPROM.writeString(EEPROM_MQTT_SERVER_URL_OFFSET, url.c_str());
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void PhConfigurationManager::saveFlashLogFrequency(uint16_t freq, bool doCommit)
{
	if (m_loadAllInProgress)
		return;
	Serial.println("EEPROM saveFlashLogFrequency: " + String(freq));
	uint16_t written = EEPROM.writeUShort(EEPROM_FLASH_LOG_FREQ_OFFSET, freq);
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void PhConfigurationManager::saveWifiRtLogFrequency(uint16_t freq, bool doCommit)
{
	if (m_loadAllInProgress)
		return;

	Serial.println("EEPROM saveWifiRtLogFrequency: " + String(freq));
	size_t written = EEPROM.writeUShort(EEPROM_WIFI_RT_LOG_FREQ_OFFSET, freq);
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void PhConfigurationManager::saveDeviceId(String id, bool doCommit)
{
	if (m_loadAllInProgress)
		return;

	Serial.println("EEPROM saveDeviceId: " + id);
	size_t written = EEPROM.writeString(EEPROM_DEVICE_ID_OFFSET, id.c_str());
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void PhConfigurationManager::setupEEPROM()
{
	if (!EEPROM.begin(EEPROM_SIZE))
	{
		Serial.println("EEPROM start failed");
		delay(60000);
		return;
	}

	Serial.println("EEPROM begin!!");
}

void PhConfigurationManager::clearEEPROM()
{
	for (size_t i = 0; i < EEPROM_SIZE; ++i)
		EEPROM.writeByte(i, 0xFF);
	EEPROM.commit();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////