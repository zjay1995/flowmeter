#include "base/Globals.h"

//include "ConfigurationManager.h"

const uint8_t c_BUTTON_DOWN_PIN = 2;
const uint8_t c_BUTTON_S_PIN = 0;
const uint8_t c_BUTTON_RIGHT_PIN = 15;
const uint8_t c_BUTTON_SINGLE_CLICK_HOLD_DURATION = 100;
const uint16_t c_BUTTON_COMBO_CLICK_HOLD_DURATION = 3000;

const uint16_t c_BUFFER_1_LO_BOUND_MV = 3000;
const uint16_t c_BUFFER_1_HI_BOUND_MV = 3600;
const uint16_t c_BUFFER_2_LO_BOUND_MV = 2100;
const uint16_t c_BUFFER_2_HI_BOUND_MV = 2950;
const uint16_t c_BUFFER_3_LO_BOUND_MV = 0;
const uint16_t c_BUFFER_3_HI_BOUND_MV = 2000;

const float    c_BUFFER_1_PH_VAL = 4.01;
const float    c_BUFFER_2_PH_VAL = 7.01;
const float    c_BUFFER_3_PH_VAL = 10.01;



const char* c_FLASH_LOG_FREQ_PARAM_NAME = "flashLogFreq";
const char* c_WIFI_RT_LOG_FREQ_PARAM_NAME = "wifiRtLogFreq";
const char* c_WIFI_SSID_PARAM_NAME = "wifiSsid";
const char* c_WIFI_PASSWORD_PARAM_NAME = "wifiPassword";
const char* c_MQTT_SERVER_URL_PARAM_NAME = "mqttServerUrl";

const char* c_BUFFER_1_MV_PARAM_NAME = "buffer1mv";
const char* c_BUFFER_2_MV_PARAM_NAME = "buffer2mv";
const char* c_BUFFER_3_MV_PARAM_NAME = "buffer3mv";

const char* c_00_SLM_MV_PARAM_NAME = "0.0_SLM_MV";
const char* c_05_SLM_MV_PARAM_NAME = "0.5_SLM_MV";
const char* c_10_SLM_MV_PARAM_NAME = "1.0_SLM_MV";
const char* c_15_SLM_MV_PARAM_NAME = "1.5_SLM_MV";
const char* c_20_SLM_MV_PARAM_NAME = "2.0_SLM_MV";
const char* c_25_SLM_MV_PARAM_NAME = "2.5_SLM_MV";


//ConfigurationManager g_configurationManager;

//FlowMeterConfigurationManager g_flowMeterConfigurationManager;

