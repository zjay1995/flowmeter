#include "flowmeter/FlowMeterConfigurationManager.h"
#include <EEPROM.h>

#include "base/Globals.h"
#include "base/SleepTimer.h"
#include "flowmeter/GasManager.h"



FlowMeterConfigurationManager::FlowMeterConfigurationManager()
{

}

void FlowMeterConfigurationManager::init()
{
	setupEEPROM();
}

void FlowMeterConfigurationManager::loadFromEEPROM()
{
	m_loadAllInProgress = true;
	
	int timerInterval = EEPROM.readInt(EEPROM_TIMER_OFFSET);
	Serial.println("config: timer interval: " + String(timerInterval));
	
	//m_sleepTimer->selectIntervalByValue( timerInterval );		

	// 1
	uint16_t _00SlmMv = EEPROM.readUShort(EEPROM_00_SLM_MV_OFFSET);
	if (_00SlmMv > 0)
		notifyParamChanged(c_00_SLM_MV_PARAM_NAME, String(_00SlmMv));
	Serial.println("config: c_00_SLM_MV_PARAM_NAME: " + String(_00SlmMv));
	m_00SlmMv = _00SlmMv;
	// 2
	uint16_t _05SlmMv = EEPROM.readUShort(EEPROM_05_SLM_MV_OFFSET);
	if (_05SlmMv > 0)
		notifyParamChanged(c_05_SLM_MV_PARAM_NAME, String(_05SlmMv));
	Serial.println("config: c_05_SLM_MV_PARAM_NAME: " + String(_05SlmMv));
	m_05SlmMv = _05SlmMv;
	// 3
	uint16_t _10SlmMv = EEPROM.readUShort(EEPROM_10_SLM_MV_OFFSET);
	if (_10SlmMv > 0)
		notifyParamChanged(c_10_SLM_MV_PARAM_NAME, String(_10SlmMv));
	Serial.println("config: c_10_SLM_MV_PARAM_NAME: " + String(_10SlmMv));
	m_10SlmMv = _10SlmMv;
	// 4
	uint16_t _15SlmMv = EEPROM.readUShort(EEPROM_15_SLM_MV_OFFSET);
	if (_15SlmMv > 0)
		notifyParamChanged(c_15_SLM_MV_PARAM_NAME, String(_15SlmMv));
	Serial.println("config: c_15_SLM_MV_PARAM_NAME: " + String(_15SlmMv));
	m_15SlmMv = _15SlmMv;
	// 5
	uint16_t _20SlmMv = EEPROM.readUShort(EEPROM_20_SLM_MV_OFFSET);
	if (_20SlmMv > 0)
		notifyParamChanged(c_20_SLM_MV_PARAM_NAME, String(_20SlmMv));
	Serial.println("config: c_20_SLM_MV_PARAM_NAME: " + String(_20SlmMv));
	m_20SlmMv = _20SlmMv;
	// 6
	uint16_t _25SlmMv = EEPROM.readUShort(EEPROM_25_SLM_MV_OFFSET);
	if (_25SlmMv > 0)
		notifyParamChanged(c_25_SLM_MV_PARAM_NAME, String(_25SlmMv));
	Serial.println("config: c_25_SLM_MV_PARAM_NAME: " + String(_25SlmMv));
	m_25SlmMv = _25SlmMv;

	
	///////////////

	// WiFi SSID
	char wifiSsid[32] = { 0 };
	size_t readSsid = EEPROM.readString(EEPROM_WIFI_SSID_OFFSET, wifiSsid, 31);
	if (readSsid > 0)
		notifyParamChanged(c_WIFI_SSID_PARAM_NAME, String(wifiSsid));
	Serial.println("config: WiFi SSID: " + String(wifiSsid));
	m_wifiSsid = wifiSsid;

	// WiFi PASSWORD
	char wifiPsw[32] = { 0 };
	size_t readPsw = EEPROM.readString(EEPROM_WIFI_PASSWORD_OFFSET, wifiPsw, 31);
	if (readPsw > 0)
		notifyParamChanged(c_WIFI_PASSWORD_PARAM_NAME, String(wifiPsw));
	Serial.println("config: WiFi PSW: " + String(wifiPsw));
	m_wifiPassword = wifiPsw;

	// MQTT SERVER URL
	char mqttUrl[64] = { 0 };
	size_t readUrl = EEPROM.readString(EEPROM_MQTT_SERVER_URL_OFFSET, mqttUrl, 63);
	if (readUrl > 0)
		notifyParamChanged(c_MQTT_SERVER_URL_PARAM_NAME, String(mqttUrl));
	Serial.println("config: MQTT SERVER URL: " + String(mqttUrl));
	m_mqttServerUrl = mqttUrl;

	// FLASH LOG FREQUENCY
	uint16_t flashLogFreq = EEPROM.readUShort(EEPROM_FLASH_LOG_FREQ_OFFSET);
	if (flashLogFreq > 0)
		notifyParamChanged(c_MQTT_SERVER_URL_PARAM_NAME, String(flashLogFreq));
	Serial.println("config: FLASH LOG FREQUENCY: " + String(flashLogFreq));
	m_flashLogFreq = flashLogFreq;

	// WIFI RT LOG FREQUENCY
	uint16_t wifiRtLogFreq = EEPROM.readUShort(EEPROM_WIFI_RT_LOG_FREQ_OFFSET);
	if (wifiRtLogFreq > 0)
		notifyParamChanged(c_MQTT_SERVER_URL_PARAM_NAME, String(wifiRtLogFreq));
	Serial.println("config: WIFI RT LOG FREQUENCY: " + String(wifiRtLogFreq));
	m_wifiRtLogFreq = wifiRtLogFreq;

	/////////////////

	m_loadAllInProgress = false;

	return;		
}

void FlowMeterConfigurationManager::addParamChangeListener(ParamChangeListener* l)
{
	m_paramChangeListeners.push_back(l);
}

void FlowMeterConfigurationManager::notifyParamChanged(String param, String value)
{
	for (auto& l : m_paramChangeListeners)
		l->onParamChange(param, value);
}

void FlowMeterConfigurationManager::onParamChange(String param, String value)
{
	Serial.println("FlowMeterConfigurationManager onParamChange" + param + " " + value);

	if (param.equals(c_FLASH_LOG_FREQ_PARAM_NAME))
	{
		Serial.println("EEPROM save c_FLASH_LOG_FREQ_PARAM_NAME: " + value);
		EEPROM.writeUShort(EEPROM_FLASH_LOG_FREQ_OFFSET, value.toInt());

		m_flashLogFreq = value.toInt();
	}
	else if (param.equals(c_WIFI_RT_LOG_FREQ_PARAM_NAME))
	{
		Serial.println("EEPROM save c_WIFI_RT_LOG_FREQ_PARAM_NAME: " + value);
		EEPROM.writeUShort(EEPROM_WIFI_RT_LOG_FREQ_OFFSET, value.toInt());

		m_wifiRtLogFreq = value.toInt();
	}
	else if (param.equals(c_WIFI_SSID_PARAM_NAME))
	{
		size_t ret = EEPROM.writeString(EEPROM_WIFI_SSID_OFFSET, value.c_str());
		Serial.println("EEPROM save c_WIFI_SSID_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_wifiSsid = value;
	}
	else if (param.equals(c_WIFI_PASSWORD_PARAM_NAME))
	{
		size_t ret = EEPROM.writeString(EEPROM_WIFI_PASSWORD_OFFSET, value.c_str());
		Serial.println("EEPROM save c_WIFI_PASSWORD_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_wifiPassword = value;
	}
	else if (param.equals(c_00_SLM_MV_PARAM_NAME))
	{
		size_t ret = EEPROM.writeUShort(EEPROM_00_SLM_MV_OFFSET, value.toInt());
		Serial.println("EEPROM save c_00_SLM_MV_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_00SlmMv = value.toInt();
	}
	else if (param.equals(c_05_SLM_MV_PARAM_NAME))
	{
		size_t ret = EEPROM.writeUShort(EEPROM_05_SLM_MV_OFFSET, value.toInt());
		Serial.println("EEPROM save c_05_SLM_MV_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_05SlmMv = value.toInt();
	}
	else if (param.equals(c_10_SLM_MV_PARAM_NAME))
	{
		size_t ret = EEPROM.writeUShort(EEPROM_10_SLM_MV_OFFSET, value.toInt());
		Serial.println("EEPROM save c_10_SLM_MV_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_10SlmMv = value.toInt();
	}
	else if (param.equals(c_15_SLM_MV_PARAM_NAME))
	{
		size_t ret = EEPROM.writeUShort(EEPROM_15_SLM_MV_OFFSET, value.toInt());
		Serial.println("EEPROM save c_15_SLM_MV_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_15SlmMv = value.toInt();
	}
	else if (param.equals(c_20_SLM_MV_PARAM_NAME))
	{
		size_t ret = EEPROM.writeUShort(EEPROM_20_SLM_MV_OFFSET, value.toInt());
		Serial.println("EEPROM save c_20_SLM_MV_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_20SlmMv = value.toInt();
	}
	else if (param.equals(c_25_SLM_MV_PARAM_NAME))
	{
		size_t ret = EEPROM.writeUShort(EEPROM_25_SLM_MV_OFFSET, value.toInt());
		Serial.println("EEPROM save c_25_SLM_MV_PARAM_NAME: " + value + " ret:" + String(ret) + " len:" + String(strlen(value.c_str())));
		m_25SlmMv = value.toInt();
	}
	if (!EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");

	// This is WebServer changing params so notify others too!
	notifyParamChanged(param, value);
}

void FlowMeterConfigurationManager::saveTimerIntervalToEEPROM(int interval, bool doCommit)
{	
	if(m_loadAllInProgress)
		return;
	Serial.println("EEPROM saveTimerIntervalToEEPROM: " + String(interval));
	size_t written = EEPROM.put(0, interval);
	Serial.println("EEPROM written: " + String(written));
	if(doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}			

void FlowMeterConfigurationManager::saveWifiSSID(String ssid, bool doCommit)
{
	if (m_loadAllInProgress)
		return;
	Serial.println("EEPROM saveWifiSSID: " + ssid);
	size_t written = EEPROM.writeString(EEPROM_WIFI_SSID_OFFSET, ssid.c_str());
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void FlowMeterConfigurationManager::saveWifiPassword(String password, bool doCommit)
{
	if (m_loadAllInProgress)
		return;
	Serial.println("EEPROM saveWifiPassword: " + password);
	size_t written = EEPROM.writeString(EEPROM_WIFI_PASSWORD_OFFSET, password.c_str());
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void FlowMeterConfigurationManager::saveMqttServerUrl(String url, bool doCommit)
{
	if (m_loadAllInProgress)
		return;
	Serial.println("EEPROM saveMqttServerUrl: " + url);
	size_t written = EEPROM.writeString(EEPROM_MQTT_SERVER_URL_OFFSET, url.c_str());
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void FlowMeterConfigurationManager::saveFlashLogFrequency(uint16_t freq, bool doCommit)
{
	if (m_loadAllInProgress)
		return;
	Serial.println("EEPROM saveFlashLogFrequency: " + String(freq));
	uint16_t written = EEPROM.writeUShort(EEPROM_FLASH_LOG_FREQ_OFFSET, freq);
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void FlowMeterConfigurationManager::saveWifiRtLogFrequency(uint16_t freq, bool doCommit)
{
	if (m_loadAllInProgress)
		return;

	Serial.println("EEPROM saveWifiRtLogFrequency: " + String(freq));
	size_t written = EEPROM.writeUShort(EEPROM_WIFI_RT_LOG_FREQ_OFFSET, freq);
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void FlowMeterConfigurationManager::saveDeviceId(String id, bool doCommit)
{
	if (m_loadAllInProgress)
		return;

	Serial.println("EEPROM saveDeviceId: " + id);
	size_t written = EEPROM.writeString(EEPROM_DEVICE_ID_OFFSET, id.c_str());
	Serial.println("EEPROM written: " + String(written));
	if (doCommit && !EEPROM.commit())
		Serial.println("EEPROM commit ERROR!!!");
}

void FlowMeterConfigurationManager::setupEEPROM()
{
	if (!EEPROM.begin(EEPROM_SIZE))
	{
		Serial.println("EEPROM start failed");
		delay(60000);
		return;
	}

	Serial.println("EEPROM begin!!");
}

void FlowMeterConfigurationManager::clearEEPROM()
{
	for (size_t i = 0; i < EEPROM_SIZE; ++i)
		EEPROM.writeByte(i, 0xFF);
	EEPROM.commit();
}