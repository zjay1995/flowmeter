


#include "base/Menu/MenuRenderer/SSD1306/SSD1306GenericMenuRenderer.h"
#include <SSD1306.h>


SSD1306GenericMenuRenderer::SSD1306GenericMenuRenderer(SSD1306Wire* display, String text) : SSD1306MenuRenderer(display),
                                                                                            m_text(text)
{


}

void SSD1306GenericMenuRenderer::render(Menu* menu)
{
	m_display->clear();
	m_display->setColor(WHITE);
	m_display->setTextAlignment(TEXT_ALIGN_CENTER);
	m_display->drawString(64, 24 , m_text);
	m_display->display();

}
