#pragma once

#include "flowmeter/Menu/MenuRenderer/SSD1327/SSD1327CalibrationMenuRenderer.h"
#include "flowmeter/Menu/FlowMeterCalibrationMenuItem.h"

#include "U8g2lib.h"

SSD1327CalibrationMenuRenderer::SSD1327CalibrationMenuRenderer(U8G2_SSD1327_MIDAS_128X128_F_4W_SW_SPI* display, FlowMeterSensorDataSource* flowMeterSensorDataSource) : SSD1327MenuRenderer(display),
																																										m_flowMeterSensorDataSource(flowMeterSensorDataSource)
{


}

void SSD1327CalibrationMenuRenderer::render(Menu* menu)
{
	FlowMeterCalibrationMenuItem* calMenuItem = (FlowMeterCalibrationMenuItem*)menu;

	m_display->clearBuffer();
	//m_display->setTextAlignment(TEXT_ALIGN_CENTER);
	m_display->drawStr(64, 0 , "Calibration");

	m_display->drawStr(64, 16 , calMenuItem->getSelectionItem().getDisplayName().c_str());	

	String mvLine = String(m_flowMeterSensorDataSource->getRawMiliVolts()) + " mv";

	m_display->drawStr(64, 30 , mvLine.c_str());	

	m_display->setFont(u8g2_font_ncenB14_tr);
	m_display->drawStr(64, 50 , calMenuItem->getInfoMessage().c_str());
	m_display->sendBuffer();

}
