#include "flowmeter/Menu/MenuRenderer/SSD1327/SSD1327RunMenuRenderer.h"
#include "flowmeter/DataSource/FlowMeterDataSource.h"
#include "flowmeter/GasManager.h"
#include <U8g2lib.h>

SSD1327RunMenuRenderer::SSD1327RunMenuRenderer(U8G2_SSD1327_MIDAS_128X128_F_4W_SW_SPI* display, FlowMeterSensorDataSource* flowMeterDataSource, GasManager* gasManager) : SSD1327MenuRenderer(display),
																														  m_flowMeterDataSource(flowMeterDataSource),
																														  m_gasManager(gasManager)	
{
	
	
}

void SSD1327RunMenuRenderer::render(Menu* menu)
{
	String textToDisplay;
	
	double sensor_val = m_flowMeterDataSource->getDoubleValue();

	Gas& selectedGas = m_gasManager->getSelectedGas();

	m_display->clearBuffer();

	String gasLine = selectedGas.getName() + " " + String(sensor_val) + "sccm";

	Serial.println(gasLine.c_str());
	m_display->drawStr(64, 1, gasLine.c_str());
	m_display->drawLine(10, 24, 256, 24);

	String mvLine = String( m_flowMeterDataSource->getRawMiliVolts() ) + "mV";

	m_display->drawStr(64, 30 , mvLine.c_str());
	m_display->sendBuffer();
}