#pragma once

#include "flowmeter/Menu/MenuRenderer/SSD1306/SSD1306CalibrationMenuRenderer.h"
#include "flowmeter/Menu/FlowMeterCalibrationMenuItem.h"
#include <SSD1306.h>


SSD1306CalibrationMenuRenderer::SSD1306CalibrationMenuRenderer(SSD1306Wire* display, FlowMeterSensorDataSource* flowMeterSensorDataSource) : SSD1306MenuRenderer(display),
																																			m_flowMeterSensorDataSource(flowMeterSensorDataSource)
{


}

void SSD1306CalibrationMenuRenderer::render(Menu* menu)
{
	FlowMeterCalibrationMenuItem* calMenuItem = (FlowMeterCalibrationMenuItem*)menu;

	m_display->clear();
	m_display->setColor(WHITE);
	m_display->setTextAlignment(TEXT_ALIGN_CENTER);
	m_display->drawString(64, 0 , "Calibration");
	m_display->drawString(64, 16 , calMenuItem->getSelectionItem().getDisplayName());	

	String mvLine = String(m_flowMeterSensorDataSource->getRawMiliVolts()) + " mv";

	m_display->drawString(64, 30 , mvLine);	

	m_display->setFont(ArialMT_Plain_16);
	m_display->drawString(64, 47 , calMenuItem->getInfoMessage());
	m_display->display();

}
