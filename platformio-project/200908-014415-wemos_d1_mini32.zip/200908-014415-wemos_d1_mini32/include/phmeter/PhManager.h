#pragma once

#include <Arduino.h>
#include "base/ParamChangeListener.h"

enum EItemOfInterest
{
	PH,
	MV
};

class PhManager : public ParamChangeListener
{

    EItemOfInterest m_eItemOfInterest;

    uint16_t m_buffer1Mv;
    uint16_t m_buffer2Mv;
    uint16_t m_buffer3Mv;


public:


    PhManager();
    ~PhManager() = default;


    void setItemOfInterest(EItemOfInterest eItemOfInterest);

    EItemOfInterest getItemOfInterest() const;

    double          calculatePh(int miliVolts);


    void setBuffer1Mv(uint16_t val);
    void setBuffer2Mv(uint16_t val);
    void setBuffer3Mv(uint16_t val);

	uint16_t getBuffer1Mv() const { return m_buffer1Mv; }
	uint16_t getBuffer2Mv() const { return m_buffer2Mv; }
	uint16_t getBuffer3Mv() const { return m_buffer3Mv; }

    bool isInBuffer1Range(uint16_t mv) const;
    bool isInBuffer2Range(uint16_t mv) const;
    bool isInBuffer3Range(uint16_t mv) const;

	void onParamChange(String param, String value);
};