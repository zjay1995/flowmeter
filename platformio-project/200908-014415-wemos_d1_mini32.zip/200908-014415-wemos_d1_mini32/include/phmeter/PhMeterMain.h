#pragma once

void setupPhMeter();
void loopPhMeter();
