#include "Menu.h"

#include "PhManager.h"

class PhMenuItem : public Menu 
{
	PhManager* m_phManager;
	


public:	

	PhMenuItem(String name, String parentName, PhManager* phManager, MenuRenderer* renderer) : Menu(name, parentName, renderer),
                                                                                                             m_phManager(phManager)
	{
		
	}

	void action(EMenuAction eMenuAction)
	{
		Serial.println("PhMenuItem action");
        if(eMenuAction == EMenuAction::S_SINGLE_CLICK_LONG)
        {
		    m_phManager->setItemOfInterest(EItemOfInterest::PH);
			Menu::exitToRunMenu();
        }
	}
	
};