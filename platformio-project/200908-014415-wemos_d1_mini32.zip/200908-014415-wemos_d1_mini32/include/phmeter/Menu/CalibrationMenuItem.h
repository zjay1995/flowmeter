#pragma once

#include "base/Menu/Menu.h"
#include "phmeter/PhManager.h"
#include "phmeter/DataSource/PhSensorDataSource.h"

class CalibrationMenuItem : public Menu 
{
	PhManager* 			m_phManager;
	
	PhSensorDataSource*	m_phSensorDataSource;

	bool m_calibrationRunning = false;

	String m_infoMessage;

public:	

	CalibrationMenuItem(String name, String parentName, PhManager* phManager, PhSensorDataSource* phSensorDataSource, MenuRenderer* renderer) : Menu(name, parentName, renderer),
                                                                                                   												m_phManager(phManager),
																																				m_phSensorDataSource(phSensorDataSource)
	{							
		
	}

	void action(EMenuAction eMenuAction)
	{
		Serial.println("CalibrationMenuItem action");
        if(eMenuAction != EMenuAction::S_SINGLE_CLICK_LONG)
			return;

		m_calibrationRunning = true;

		m_infoMessage = "Calibrating...";

		Menu::doRender();

		vTaskDelay(5000);

		int sum = 0;
		for(int i = 0; i < 20; i++)
			sum += m_phSensorDataSource->getMiliVoltsInstant();

		double avg = sum / 20.0;

		int16_t mv = (int16_t)round(avg);

		if(m_phManager->isInBuffer1Range(mv))
			m_phManager->setBuffer1Mv(mv);
		else if(m_phManager->isInBuffer2Range(mv))
			m_phManager->setBuffer2Mv(mv);
		else if(m_phManager->isInBuffer3Range(mv))
			m_phManager->setBuffer3Mv(mv);

		String number = m_phManager->isInBuffer1Range(mv) ? "1" : 
					   (m_phManager->isInBuffer2Range(mv) ? "2" :
					   (m_phManager->isInBuffer3Range(mv) ? "3" : 
					   										"X"));

		if(number == "X")
			m_infoMessage = "Failed to find buffer for mv: " + String(mv);
		else
			m_infoMessage = "Buf " + number + " set to:" + String(mv);

		m_calibrationRunning = false;
		//Menu::exitToRunMenu();
	}

	String getInfoMessage() const 	{ return m_infoMessage; 	   }

	bool calibrationRunning() const { return m_calibrationRunning; }
	
};