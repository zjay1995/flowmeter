#pragma once

#include "base/Menu/MenuRenderer/MenuRenderer.h"

class SSD1306MenuRenderer;
class PhSensorDataSource;
class PhManager;

class SSD1306CalibrationMenuRenderer : public SSD1306MenuRenderer
{
	
public:

	SSD1306CalibrationMenuRenderer(SSD1306Wire* display);

	void render(Menu* menu);
};