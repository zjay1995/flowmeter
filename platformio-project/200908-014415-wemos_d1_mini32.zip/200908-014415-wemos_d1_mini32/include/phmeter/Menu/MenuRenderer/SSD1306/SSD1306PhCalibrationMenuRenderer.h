#pragma once

#include "base/Menu/MenuRenderer/MenuRenderer.h"
#include "base/Menu/MenuRenderer/SSD1306/SSDGenericMenuWithSelectionRenderer.h"

class SSD1306MenuRenderer;
class PhSensorDataSource;
class PhManager;

class SSD1306PhCalibrationMenuRenderer : public SSD1306GenericMenuWithSelectionRenderer
{
	
public:

	SSD1306PhCalibrationMenuRenderer(SSD1306Wire* display);

	void render(Menu* menu);
};