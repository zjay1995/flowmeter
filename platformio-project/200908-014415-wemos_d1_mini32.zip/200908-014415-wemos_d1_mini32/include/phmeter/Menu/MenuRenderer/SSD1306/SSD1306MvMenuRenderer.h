#pragma once

#include "base/Menu/MenuRenderer/MenuRenderer.h"

class PhSensorDataSource;
class PhManager;

class SSD1306MvMenuRenderer : public SSD1306MenuRenderer
{
	PhSensorDataSource* m_phSensorDataSource;
	PhManager*			m_phManager;
	
public:

	SSD1306MvMenuRenderer(SSD1306Wire* display, PhManager* phManager);

	void render(Menu* menu);
};