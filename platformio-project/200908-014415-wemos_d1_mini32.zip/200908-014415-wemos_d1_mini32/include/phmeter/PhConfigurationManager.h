#pragma once

#include <Arduino.h>

#include "base/ParamChangeListener.h"

class SleepTimer;
class GasManager;

class PhConfigurationManager : public ParamChangeListener
{
	
const uint16_t EEPROM_SIZE = sizeof(int) + 				// TIMER
							sizeof(double) * (2 + 8)	// GASES
							+ 200;
	
const uint8_t EEPROM_TIMER_OFFSET = 0;
const uint8_t EEPROM_DEVICE_ID_OFFSET = 4;			//64 chars
const uint8_t EEPROM_WIFI_SSID_OFFSET = 68;			//32 chars
const uint8_t EEPROM_WIFI_PASSWORD_OFFSET = 100;	//32 chars
const uint8_t EEPROM_MQTT_SERVER_URL_OFFSET = 132;	//64 chars
const uint8_t EEPROM_FLASH_LOG_FREQ_OFFSET = 196;	//uint16_t
const uint8_t EEPROM_WIFI_RT_LOG_FREQ_OFFSET = 198;	//uint16_t
const uint8_t EEPROM_BUFFER_1_MV_OFFSET = 200;
const uint8_t EEPROM_BUFFER_2_MV_OFFSET = 202;
const uint8_t EEPROM_BUFFER_3_MV_OFFSET = 204;

	bool m_loadAllInProgress = false;

	std::vector<ParamChangeListener*> m_paramChangeListeners;

	String m_wifiSsid;
	String m_wifiPassword;
	String m_deviceId;
	uint16_t m_wifiRtLogFreq;
	uint16_t m_flashLogFreq;
	String m_mqttServerUrl;
	uint16_t m_buffer1Mv;
	uint16_t m_buffer2Mv;
	uint16_t m_buffer3Mv;

public:

	PhConfigurationManager();
	
	void init();
	
	void loadFromEEPROM();
		
	void saveTimerIntervalToEEPROM(int interval, bool doCommit = true);
	void saveWifiSSID(String ssid, bool doCommit = true);
	void saveWifiPassword(String password, bool doCommit = true);
	void saveMqttServerUrl(String url, bool doCommit = true);
	void saveFlashLogFrequency(uint16_t freq, bool doCommit = true);
	void saveWifiRtLogFrequency(uint16_t freq, bool doCommit = true);
	void saveDeviceId(String id, bool doCommit = true);

	// Getters
	String getWifiSsid() const { return m_wifiSsid; }
	String getWifiPassword() const { return m_wifiPassword; }
	String getDeviceId() const { return m_deviceId; }
	String getWifiRtLogFreqAsString() const { return String(m_wifiRtLogFreq); }
	String getFlashLogFreqAsString() const { return String(m_flashLogFreq); }
	String getMqttServerUrl() const { return m_mqttServerUrl; }
	String getBuffer1MvAsString() const { return String(m_buffer1Mv); }
	String getBuffer2MvAsString() const { return String(m_buffer2Mv); }
	String getBuffer3MvAsString() const { return String(m_buffer3Mv); }
	uint16_t getBuffer1Mv() const { return m_buffer1Mv; }
	uint16_t getBuffer2Mv() const { return m_buffer2Mv; }
	uint16_t getBuffer3Mv() const { return m_buffer3Mv; }

	void setupEEPROM();
	
	void clearEEPROM();

	void onParamChange(String param, String value);


	void addParamChangeListener(ParamChangeListener* l);
	void notifyParamChanged(String param, String value);

};