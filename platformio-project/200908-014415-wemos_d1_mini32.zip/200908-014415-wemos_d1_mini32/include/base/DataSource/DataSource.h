#pragma once

#include <Arduino.h>

class AnalogSourceInput;

class DataSource
{

protected:

    AnalogSourceInput* m_analogSourceInput;

public:

	DataSource(AnalogSourceInput* analogSourceInput);
	~DataSource()=default;
	
	uint16_t getRawMiliVolts() const;
	
	uint16_t getMiliVoltsInstant() const;

	virtual double getDoubleValue() = 0;
	virtual double getDoubleValue(uint16_t mv) = 0;

};