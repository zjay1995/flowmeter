#pragma once

#include <Arduino.h>

class File;
class DataSource;

class RecordManager
{
public:

    virtual String  readRecordAsJson(File* file) = 0;
    
    virtual bool    writeRecordToFile(DataSource* dataSource, File* file) = 0;
};


