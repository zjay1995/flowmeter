#pragma once

#include <SPIFFS.h>

#include <time.h>
#include <sys/time.h>

class GasManager;
class DataSource;

class MQTTFlashPublisher;
class MQTTRealTimePublisher;

class DataLogger
{
	int m_singleFileLimit = 10;
	int m_maxSize;
	File m_file;
	
	bool m_sessionRunning = false;
	
	bool m_isSingleShotLog = false;

	int m_currentValueCount = 0;
	
	int m_secondsBetweenDataPoints = 1;

	unsigned long m_lastTickMillis = 0;

	DataSource* m_dataSource;

	MQTTFlashPublisher* m_mqttFlashPublisher;
	MQTTRealTimePublisher* m_mqttRealTimePublisher;
	
	String m_currentSessionTimestamp;
	int m_fileIndex = 0;
	String m_currentFileName;
	
	String m_fileNamePart;

	//virtual String createFileName(String ts, String gas, int secondsBetweenDataPoints, int fileIndex) = 0;
	String createFileName(String ts, String name, int secondsBetweenDataPoints, int fileIndex);


	String getCurrentDateTimeStr();

	void checkIfGracefulShutdown();

	bool shouldExecTick();

public:

	DataLogger()=default;
	~DataLogger()=default;
	

	void init(DataSource* dataSource);
		
	void handleTick();

	void stopWiFiDumpSession();
	void startWiFiDumpSession();
	bool isWiFiDumpRunning();

	void stopWiFiRealTimeDumpSession();
	void startWiFiRealTimeDumpSession();
	bool isWiFiRealTimeDumpRunning();

	bool startFlashStoreSession();
	bool stopFlashStoreSession();
	
	bool isFlashStoreSessionRunning() const;

	bool doSingleShotFlashLog();

	void setFileNamePart(String fileNamePart);

	MQTTFlashPublisher*		getMqttFlashPublisher()		const;
	MQTTRealTimePublisher*	getMqttRealTimePublisher()	const;

public:


	static portMUX_TYPE s_mtxLogger;

};