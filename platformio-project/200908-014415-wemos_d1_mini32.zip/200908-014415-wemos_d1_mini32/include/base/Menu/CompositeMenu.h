#pragma once

#include "Menu.h"


class CompositeMenu : public MenuWithSelection
{
	std::vector<MenuWithSelection*> m_menus;
	int m_currentIndex;
	
public:	

	CompositeMenu(String name, String parentName, std::vector<MenuWithSelection*> menus);

	Menu* getCurrentMenu();
	void  moveToFirst();
	void  moveToPrev();
	void  moveToNext();

	void  action(EMenuAction eMenuAction) override;
	
	void  render() override;
	
	void  print();
	
};

