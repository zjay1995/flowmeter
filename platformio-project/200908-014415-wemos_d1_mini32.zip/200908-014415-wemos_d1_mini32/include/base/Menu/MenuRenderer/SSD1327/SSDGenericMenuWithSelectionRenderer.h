#pragma once


#include "base/Menu/MenuRenderer/MenuRenderer.h"
#include "base/Menu/Menu.h"

#include "U8g2lib.h"


class SSD1327GenericMenuWithSelectionRenderer : public SSD1327MenuRenderer
{

public:

	SSD1327GenericMenuWithSelectionRenderer(U8G2_SSD1327_MIDAS_128X128_F_4W_SW_SPI * display) : SSD1327MenuRenderer(display){}

	void render(Menu* menu)
    {
        MenuWithSelection* menuWithSelection = (MenuWithSelection*)menu;


        m_display->clearBuffer();
        m_display->setColor(1);
       //m_display->setTextAlignment(TEXT_ALIGN_CENTER);
        m_display->drawStr(64, 0, menuWithSelection->getName().c_str());
        m_display->drawLine(10, 24, 256, 24);
        m_display->drawStr(64, 30 , menuWithSelection->getSelectionItem().getDisplayName().c_str());
        m_display->sendBuffer();
    }


};