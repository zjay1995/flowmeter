#pragma once


#include "base/Menu/MenuRenderer/MenuRenderer.h"
#include "base/Menu/Menu.h"
#include <SSD1306.h>


class SSD1306GenericMenuWithSelectionRenderer : public SSD1306MenuRenderer
{

public:

	SSD1306GenericMenuWithSelectionRenderer(SSD1306Wire* display) : SSD1306MenuRenderer(display){}

	void render(Menu* menu)
    {
        MenuWithSelection* menuWithSelection = (MenuWithSelection*)menu;

        String menuName = menu->getName();

        m_display->clear();
        m_display->setColor(WHITE);
        m_display->setTextAlignment(TEXT_ALIGN_CENTER);
        m_display->drawString(64, 0, menuWithSelection->getName());
        m_display->drawLine(10, 24, 256, 24);
        m_display->drawString(64, 30 , menuWithSelection->getSelectionItem().getDisplayName());
        m_display->display();
    }


};