#pragma once

#include <Arduino.h>

class ParamChangeListener
{
public:

	virtual void onParamChange(String param, String value) = 0;

};
