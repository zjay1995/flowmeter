#pragma once

#include "base/Menu/Menu.h"
#include "flowmeter/GasManager.h"


class GasLibraryMenu : public MenuWithSelection 
{
	GasManager* m_gasManager;
	
public:	

	GasLibraryMenu(String name, String parentName, GasManager* gasManager, MenuRenderer* renderer) : MenuWithSelection(name, parentName, renderer),
																									m_gasManager(gasManager)
																								
	{
		for (auto& gas : gasManager->getAllGases())
			m_selectionItems.push_back(MenuSelectionItem(gas.getName(), gas.getName()));
	}

	void selectNext()
	{
		Serial.println("GasLibraryMenu selectNext " + String(m_selectionItems.size())); 
		MenuWithSelection::selectNext();
		m_gasManager->selectNextGas();
	}

	void selectPrevious()
	{
		Serial.println("GasLibraryMenu selectPrevious " + String(m_selectionItems.size())); 
		MenuWithSelection::selectPrevious();
		m_gasManager->selectPreviousGas();
	}
};

class RunMenuItem : public MenuWithSelection 
{
	GasManager* m_gasManager;
	
public:	

	RunMenuItem(String name, String parentName, GasManager* gasManager, MenuRenderer* renderer) 
		: MenuWithSelection(name, parentName, renderer),
		  m_gasManager(gasManager)
	{
		
	}

	void action(EMenuAction eMenuAction)
	{
		//m_gasManager->selectGasByIndex(m_gasIndex);	
	}
	
};

class SleepTimerMenuItem : public Menu 
{
	SleepTimer* m_sleepTimer;
	
	int m_intervalIndex;
	
public:	

	SleepTimerMenuItem(String name, String parentName, int intervalIndex, SleepTimer* sleepTimer, MenuRenderer* renderer) 
		: Menu(name, parentName, renderer),
		m_sleepTimer(sleepTimer),
		m_intervalIndex(intervalIndex)
	{
		
	}

	void action(EMenuAction eMenuAction)
	{
		m_sleepTimer->selectIntervalByIndex(m_intervalIndex);
	}
	
};

class DataLoggerFlashStoreMenuItem : public Menu 
{
	DataLogger* m_dataLogger;
	
public:	

	DataLoggerFlashStoreMenuItem(String name, String parentName, DataLogger* dataLogger, MenuRenderer* renderer) 
		: Menu(name, parentName, renderer),
		m_dataLogger(dataLogger)
	{

	}

	void action(EMenuAction eMenuAction)
	{
		if( m_dataLogger->isFlashStoreSessionRunning() )
			m_dataLogger->stopFlashStoreSession();
		else
			m_dataLogger->startFlashStoreSession();
	}
	
};

class WiFiDumpMenuItem : public Menu
{
	DataLogger* m_dataLogger;

public:

	WiFiDumpMenuItem(String name, String parentName, DataLogger* dataLogger, MenuRenderer* renderer)
		: Menu(name, parentName, renderer),
		m_dataLogger(dataLogger)
	{

	}

	void action(EMenuAction eMenuAction)
	{
		if (m_dataLogger->isWiFiDumpRunning())
			m_dataLogger->stopWiFiDumpSession();
		else
			m_dataLogger->startWiFiDumpSession();
	}

};

class WiFiRealTimeDumpMenuItem : public Menu
{
	DataLogger* m_dataLogger;

public:

	WiFiRealTimeDumpMenuItem(String name, String parentName, DataLogger* dataLogger, MenuRenderer* renderer)
		: Menu(name, parentName, renderer),
		m_dataLogger(dataLogger)
	{

	}

	void action(EMenuAction eMenuAction)
	{
		if (m_dataLogger->isWiFiRealTimeDumpRunning())
			m_dataLogger->stopWiFiRealTimeDumpSession();
		else
			m_dataLogger->startWiFiRealTimeDumpSession();
	}

};

class NTPSyncMenuItem : public Menu
{

	TimeSync* m_timeSync;

public:

	NTPSyncMenuItem(String name, String parentName, TimeSync* timeSync, MenuRenderer* renderer)
		: Menu(name, parentName, renderer)
	{
		m_timeSync = timeSync;
	}

	void action(EMenuAction eMenuAction)
	{
		if(!m_timeSync->isNTCSyncRunning())
			m_timeSync->startNTPSync();
		else
		{
			m_timeSync->stopNTPSync();
		}
		
	}

};

class ShowTimeMenuItem : public Menu
{

public:

	ShowTimeMenuItem(String name, String parentName, MenuRenderer* renderer)
		: Menu(name, parentName, renderer)
	{

	}

	void action(EMenuAction eMenuAction)
	{

	}

};