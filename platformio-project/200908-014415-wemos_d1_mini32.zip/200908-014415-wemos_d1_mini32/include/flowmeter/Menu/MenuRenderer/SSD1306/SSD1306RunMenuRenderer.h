#pragma once

#include "base/Menu/MenuRenderer/MenuRenderer.h"

#include <SSD1306.h>

class FlowMeterSensorDataSource;
class GasManager;

class SSD1306RunMenuRenderer : public SSD1306MenuRenderer
{
	FlowMeterSensorDataSource*  m_flowMeterDataSource;
	GasManager*			 		m_gasManager;
	
public:

	SSD1306RunMenuRenderer(SSD1306* display, FlowMeterSensorDataSource* flowMeterDataSource, GasManager* gasManager);

	void render(Menu* menu);
};