#pragma once

#include "base/Menu/MenuRenderer/MenuRenderer.h"

class FlowMeterSensorDataSource;
class GasManager;
class U8G2_SSD1327_MIDAS_128X128_F_4W_SW_SPI;


class SSD1327RunMenuRenderer : public SSD1327MenuRenderer
{
	FlowMeterSensorDataSource*  m_flowMeterDataSource;
	GasManager*			 		m_gasManager;
	
public:

	SSD1327RunMenuRenderer(U8G2_SSD1327_MIDAS_128X128_F_4W_SW_SPI* display, FlowMeterSensorDataSource* flowMeterDataSource, GasManager* gasManager);

	void render(Menu* menu);
};