#pragma once

#include "base/Menu/MenuRenderer/MenuRenderer.h"

class SSD1306MenuRenderer;
class PhSensorDataSource;
class PhManager;
class FlowMeterSensorDataSource;


class SSD1327CalibrationMenuRenderer : public SSD1327MenuRenderer
{

	FlowMeterSensorDataSource* m_flowMeterSensorDataSource;
	
public:

	SSD1327CalibrationMenuRenderer(U8G2_SSD1327_MIDAS_128X128_F_4W_SW_SPI* display, FlowMeterSensorDataSource* FlowMeterSensorDataSource);

	void render(Menu* menu);
};