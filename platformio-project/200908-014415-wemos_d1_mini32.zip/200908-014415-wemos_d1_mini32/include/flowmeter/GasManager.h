#pragma once

#include <vector>

#include <Arduino.h>

#include "base/LinearRegression.h"

#include "base/Globals.h"
#include "base/ParamChangeListener.h"

class Gas
{
	String m_name;	
	double m_slope;
	double m_intercept;
	double m_thermalConductivity;
	
public:
	
	Gas(String name, double thermalConductivity = 1.0) : m_name(name),
													   m_thermalConductivity(thermalConductivity)
	{
		
	}
	
	String getName() { return m_name; }

	double getThermalConductivity() const 					{ return m_thermalConductivity; }
	void setThermalConductivity(double thermalConductivity) { m_thermalConductivity = thermalConductivity; }
	
};



class GasManager : public ParamChangeListener
{
	std::vector<Gas> m_gases;
	
	int m_selectedGas = 0;

	LinearRegression m_linearRegressionCalculator;

	std::vector<double> m_miliVoltReadings;
	std::vector<double> m_slmValues;
	
	std::vector<ParamChangeListener*> m_paramChangeListeners;

public:

	GasManager() { init(); }

	GasManager(std::vector<double> miliVoltReadings, std::vector<double> slmValues) : m_miliVoltReadings(miliVoltReadings),
																					  m_slmValues(slmValues)
	{


		m_linearRegressionCalculator.calculateInterceptAndSlope(m_miliVoltReadings, m_slmValues);		
	}	

	~GasManager() {}	
	
	
	void init()
	{
		m_slmValues.push_back(0.0); m_miliVoltReadings.push_back(0);
		m_slmValues.push_back(0.5); m_miliVoltReadings.push_back(0);
		m_slmValues.push_back(1.0); m_miliVoltReadings.push_back(0);
		m_slmValues.push_back(1.5); m_miliVoltReadings.push_back(0);
		m_slmValues.push_back(2.0); m_miliVoltReadings.push_back(0);
		m_slmValues.push_back(2.5); m_miliVoltReadings.push_back(0);
	}

	double calculateSLM(double voltage) {
		//double val = (m_slope * voltage + m_intercept) * getSelectedGas().getThermalConductivity();
		return m_linearRegressionCalculator.calculateYforX(voltage) * getSelectedGas().getThermalConductivity();
		//Serial.println("calculateSLM " + String(val) + " " + String(voltage) + " " + String(getSelectedGas().getThermalConductivity()) + " " + String(m_slope) + " " + String(m_intercept));
	}
	
	void setMilivoltsReading(int16_t mv, int index)
	{
		Serial.println("setMilivoltsReading " + String(mv) + " " + String(index) + " size:" + String(m_miliVoltReadings.size()));
		if(index >= 0 && index < m_miliVoltReadings.size())
		{
			Serial.println("setMilivoltsReading " + String(mv) + " " + String(index));
			m_miliVoltReadings[index] = mv;		

			switch(index)
			{
				case 0:
					notifyOnParamChanged(c_00_SLM_MV_PARAM_NAME, String(mv));
					break;
				case 1:
					notifyOnParamChanged(c_05_SLM_MV_PARAM_NAME, String(mv));
					break;
				case 2:
					notifyOnParamChanged(c_10_SLM_MV_PARAM_NAME, String(mv));
					break;
				case 3:
					notifyOnParamChanged(c_15_SLM_MV_PARAM_NAME, String(mv));
					break;
				case 4:
					notifyOnParamChanged(c_20_SLM_MV_PARAM_NAME, String(mv));
					break;
				case 5:
					notifyOnParamChanged(c_25_SLM_MV_PARAM_NAME, String(mv));
					break;
			}

			m_linearRegressionCalculator.calculateInterceptAndSlope(m_miliVoltReadings, m_slmValues);	
		}
	}
	
	void addGas(Gas g) { m_gases.push_back(g); }
	
	void selectNextGas()
	{
		m_selectedGas = (m_selectedGas + 1) % m_gases.size();
	}
	
	void selectGasByIndex(int index)
	{
		if(index >= 0 && index < m_gases.size())
		{
			m_selectedGas = index;
		}
	}

	void selectGasByName(String gasName)
	{
		for (int i = 0; i < m_gases.size(); i++)
		{
			Gas gas = m_gases[i];

			if (m_gases[i].getName().equals(gasName))
			{
				selectGasByIndex(i);
				break;
			}
		}
	}
	
	void selectPreviousGas()
	{
		if(m_selectedGas == 0)
			m_selectedGas = m_gases.size() - 1;
		else
			m_selectedGas = m_selectedGas - 1;
	}
	
	Gas& getSelectedGas() { return m_gases[m_selectedGas]; }
	
	
	std::vector<Gas>& getAllGases() { return m_gases; }
	
	void onParamChange(String param, String value)
	{

		Serial.println("GasManager onParamChange: " + param + "=" + value);
		
		if(param.equals(c_00_SLM_MV_PARAM_NAME))
		{
			m_miliVoltReadings[0] = value.toDouble();
			m_linearRegressionCalculator.calculateInterceptAndSlope(m_miliVoltReadings, m_slmValues);	
			Serial.println("Setting c_00_SLM_MV_PARAM_NAME: " + value);
		}
		else if(param.equals(c_05_SLM_MV_PARAM_NAME))
		{
			m_miliVoltReadings[1] = value.toDouble();
			Serial.println("Setting c_05_SLM_MV_PARAM_NAME: " + value);
			m_linearRegressionCalculator.calculateInterceptAndSlope(m_miliVoltReadings, m_slmValues);	
		}
		else if(param.equals(c_10_SLM_MV_PARAM_NAME))
		{
			m_miliVoltReadings[2] = value.toDouble();
			Serial.println("Setting c_10_SLM_MV_PARAM_NAME: " + value);
			m_linearRegressionCalculator.calculateInterceptAndSlope(m_miliVoltReadings, m_slmValues);	
		}
		else if(param.equals(c_15_SLM_MV_PARAM_NAME))
		{
			m_miliVoltReadings[3] = value.toDouble();
			Serial.println("Setting c_15_SLM_MV_PARAM_NAME: " + value);
			m_linearRegressionCalculator.calculateInterceptAndSlope(m_miliVoltReadings, m_slmValues);	
		}
		else if(param.equals(c_20_SLM_MV_PARAM_NAME))
		{
			m_miliVoltReadings[4] = value.toDouble();
			Serial.println("Setting c_20_SLM_MV_PARAM_NAME: " + value);
			m_linearRegressionCalculator.calculateInterceptAndSlope(m_miliVoltReadings, m_slmValues);	
		}
		else if(param.equals(c_25_SLM_MV_PARAM_NAME))
		{
			m_miliVoltReadings[5] = value.toDouble();
			Serial.println("Setting c_25_SLM_MV_PARAM_NAME: " + value);
			m_linearRegressionCalculator.calculateInterceptAndSlope(m_miliVoltReadings, m_slmValues);	
		}										
		else
		{
			for (auto& gas : m_gases)
			{
				if (gas.getName().equals(param))
				{
					double tc = value.toDouble();
					gas.setThermalConductivity(tc);
					Serial.println("Setting TC for gas: " + gas.getName() + " " + String(tc));
					break;
				}
			}
		}
	}

	void addParamChangeListener(ParamChangeListener* l) { m_paramChangeListeners.push_back(l); }

	void notifyOnParamChanged(String param, String value)
	{
		Serial.println("gasManager notifyOnParamChanged" + param + " " + value);
		#ifdef DEBUG_PRINT_ON
		Serial.println(String(param) + "=" + String(value));
		#endif

		for (auto& l : m_paramChangeListeners)
			l->onParamChange(param, value);
	}
};