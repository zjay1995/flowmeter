/*
#pragma once

#include <SPIFFS.h>

#include <time.h>
#include <sys/time.h>

class GasManager;
class DataSource;

class MQTTFlashPublisher;
class MQTTRealTimePublisher;

class FlowSensorDataLogger : public DataLogger
{
	GasManager* m_gasManager;

	String createFileName(String ts, String name, int secondsBetweenDataPoints, int fileIndex);

public:

	FlowSensorDataLogger()=default;
	~FlowSensorDataLogger()=default;
	

	void init(DataSource* dataSource, GasManager* gasManager);


	MQTTFlashPublisher*		getMqttFlashPublisher()		const;
	MQTTRealTimePublisher*	getMqttRealTimePublisher()	const;
public:

	static portMUX_TYPE s_mtxLogger;

};
*/