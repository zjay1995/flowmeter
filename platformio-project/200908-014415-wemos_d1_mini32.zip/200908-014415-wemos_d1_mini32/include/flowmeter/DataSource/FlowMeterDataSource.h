#pragma once

#include "base/DataSource/AnalogSourceInput.h"
#include "flowmeter/GasManager.h"
#include "base/DataSource/DataSource.h"

class FlowMeterSensorDataSource : public DataSource
{
	GasManager* 		m_gasManager;
	
public:

	FlowMeterSensorDataSource(GasManager* gasManager, AnalogSourceInput* analogSourceInput) : DataSource(analogSourceInput),
																					          m_gasManager(gasManager)
	{
		
	}
	~FlowMeterSensorDataSource()=default;

	double getDoubleValue()
	{
		uint16_t miliVolts = m_analogSourceInput->getMiliVolts();
		return m_gasManager->calculateSLM(miliVolts);
	}	

	double getDoubleValue(uint16_t mv)
	{
		return m_gasManager->calculateSLM(mv);
	}
	

};