#pragma once

void setupFlowMeter();
void loopFlowMeter();